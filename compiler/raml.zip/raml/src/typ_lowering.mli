open Std
open Std.Data

type error =
  | UnsupportedSourceKind of { kind: Source_unit.kind }
  | UnsupportedItem of {
      item_id: Typ.Model.ItemId.t;
      kind: string;
      scope_path: Typ.Model.IdentPath.t
    }
  | MissingBinding of { binding_id: Typ.Model.BindingId.t }
  | MissingExpr of { expr_id: Typ.Model.ExprId.t }
  | MissingPattern of { pattern_id: Typ.Model.PatId.t }
  | UnsupportedBinding of { binding_id: Typ.Model.BindingId.t; reason: string }
  | UnsupportedPattern of { pattern_id: Typ.Model.PatId.t; reason: string }
  | UnsupportedExpr of { expr_id: Typ.Model.ExprId.t; reason: string }
  | InvalidIntLiteral of { expr_id: Typ.Model.ExprId.t; literal: string }
  | InvalidFloatLiteral of { expr_id: Typ.Model.ExprId.t; literal: string }
val error_to_json: error -> Json.t

val lower_file:
  source_unit:Source_unit.t ->
  Typ.Model.SemanticTree.file ->
  (Core_ir.Compilation_unit.t, error list) result
