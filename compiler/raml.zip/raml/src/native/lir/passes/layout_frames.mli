val program: 'a -> 'a
