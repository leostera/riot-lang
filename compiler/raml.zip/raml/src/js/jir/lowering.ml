open Std
open Std.Data
module Core = Core_ir
module Jir = Types

type error =
  | UnsupportedModuleKind of { kind: Source_unit.kind }
  | UnsupportedGroup of { group_index: int; reason: string }
  | UnsupportedBinding of { name: string; reason: string }
  | UnsupportedExpr of { reason: string }

type 'value validation = ('value, error list) result

let ok = fun value -> Ok value

let error = fun value -> Error [ value ]

let validation_map2 = fun left right f ->
  match (left, right) with
  | (Ok left, Ok right) -> Ok (f left right)
  | (Error left, Ok _) -> Error left
  | (Ok _, Error right) -> Error right
  | (Error left, Error right) -> Error (left @ right)

let map_results = fun items f ->
  List.fold_right
    (fun item acc -> validation_map2 (f item) acc (fun item acc -> item :: acc))
    items
    (Ok [])

let source_kind_to_string = fun kind ->
  match kind with
  | Source_unit.Implementation -> "implementation"
  | Source_unit.Interface -> "interface"

let error_to_json = fun error ->
  match error with
  | UnsupportedModuleKind { kind } -> Json.obj
    [
      ("kind", Json.string "unsupported_module_kind");
      ("source_kind", Json.string (source_kind_to_string kind));
    ]
  | UnsupportedGroup { group_index; reason } -> Json.obj
    [
      ("group_index", Json.int group_index);
      ("kind", Json.string "unsupported_group");
      ("reason", Json.string reason);
    ]
  | UnsupportedBinding { name; reason } -> Json.obj
    [
      ("kind", Json.string "unsupported_binding");
      ("name", Json.string name);
      ("reason", Json.string reason);
    ]
  | UnsupportedExpr { reason } -> Json.obj
    [ ("kind", Json.string "unsupported_expr"); ("reason", Json.string reason); ]

let lower_constant = fun constant ->
  match constant with
  | Core.Constant.Unit -> ok Jir.Literal.Undefined
  | Core.Constant.Bool value -> ok (Jir.Literal.Bool value)
  | Core.Constant.Int value -> ok (Jir.Literal.Number (Jir.Literal.Int value))
  | Core.Constant.Float value -> ok (Jir.Literal.Number (Jir.Literal.Float value))
  | Core.Constant.String value -> ok (Jir.Literal.String value)

let rec lower_expr = fun expr ->
  match expr with
  | Core.Expr.Constant constant ->
      Result.map (fun literal -> Jir.Expr.Literal literal) (lower_constant constant)
  | Core.Expr.Var name ->
      ok (Jir.Expr.Identifier name)
  | Core.Expr.Apply { callee=Core.Expr.Direct function_name; arguments } ->
      let callee = ok (Jir.Expr.Identifier function_name) in
      let arguments = map_results arguments lower_expr in
      validation_map2
        callee
        arguments
        (fun callee arguments -> Jir.Expr.Call Jir.Expr.{ callee; arguments })
  | Core.Expr.Apply { callee=Core.Expr.Indirect _; _ } ->
      error
        (UnsupportedExpr {
          reason = "indirect calls are outside the first Core IR -> JIR lowering slice"
        })
  | Core.Expr.Lambda _ ->
      error
        (UnsupportedExpr {
          reason = "lambda expressions are outside the first Core IR -> JIR lowering slice"
        })
  | Core.Expr.Let _ ->
      error
        (UnsupportedExpr {
          reason = "let expressions are outside the first Core IR -> JIR lowering slice"
        })
  | Core.Expr.Sequence _ ->
      error
        (UnsupportedExpr {
          reason = "sequence expressions are outside the first Core IR -> JIR lowering slice"
        })
  | Core.Expr.If_then_else _ ->
      error
        (UnsupportedExpr {
          reason = "if expressions are outside the first Core IR -> JIR lowering slice"
        })
  | Core.Expr.Primitive _ ->
      error
        (UnsupportedExpr {
          reason = "primitive expressions are outside the first Core IR -> JIR lowering slice"
        })

let lower_item = fun item ->
  match item with
  | Core.Init_item.Binding binding -> (
      match binding.expr with
      | Core.Expr.Lambda _ -> error
        (UnsupportedBinding {
          name = binding.name;
          reason = "top-level lambda bindings are outside the first Core IR -> JIR lowering slice"
        })
      | expr -> Result.map
        (fun init ->
          Jir.Statement.Declaration Jir.Declaration.{
            kind = Jir.Declaration.Const;
            name = binding.name;
            init
          })
        (lower_expr expr)
    )
  | Core.Init_item.Eval expr -> Result.map
    (fun expr -> Jir.Statement.Expression expr)
    (lower_expr expr)

let lower_group = fun group_index (group: Core.Binding_group.t) ->
  match group.rec_flag with
  | Core.Rec_flag.Recursive -> error
    (UnsupportedGroup {
      group_index;
      reason = "recursive groups are outside the first Core IR -> JIR lowering slice"
    })
  | Core.Rec_flag.Nonrecursive -> map_results group.items lower_item

let lower_export = fun (export: Core.Export.t) ->
  Jir.Export.{ name = export.name; local = export.symbol }

let lower_compilation_unit = fun (compilation_unit: Core.Compilation_unit.t) ->
  match compilation_unit.unit_id.kind with
  | Source_unit.Interface -> error (UnsupportedModuleKind { kind = compilation_unit.unit_id.kind })
  | Source_unit.Implementation ->
      let groups =
        List.mapi (fun index group -> (index + 1, group)) compilation_unit.init
      in
      let lowered_body = map_results
        groups
        (fun (group_index, group) -> lower_group group_index group)
      |> Result.map List.flatten
      |> Result.map Passes.Normalize.program in
      Result.map
        (fun body ->
          Jir.Program.{
            module_name = compilation_unit.unit_id.unit_name;
            imports = [];
            body;
            exports = List.map lower_export compilation_unit.exports
          })
        lowered_body
