open Std.Data

type requirement = {
  from: string;
  imported: string option;
  local: string;
}
val make: from:string -> ?imported:string -> local:string -> unit -> requirement

val equal: requirement -> requirement -> bool

val to_json: requirement -> Json.t
