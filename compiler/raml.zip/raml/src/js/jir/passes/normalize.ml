module Jir = Types

let rec collect_expr_imports = fun expr imports ->
  match expr with
  | Jir.Expr.Literal _ -> imports
  | Jir.Expr.Identifier _ -> imports
  | Jir.Expr.Imported requirement -> requirement :: imports
  | Jir.Expr.Runtime_helper helper -> Runtime.to_import helper :: imports
  | Jir.Expr.Call { callee; arguments } ->
      let imports = collect_expr_imports callee imports in
      collect_expr_import_list arguments imports

and collect_expr_import_list = fun exprs imports ->
  match exprs with
  | [] -> imports
  | expr :: rest ->
      let imports = collect_expr_imports expr imports in
      collect_expr_import_list rest imports

let collect_statement_imports = fun statement imports ->
  match statement with
  | Jir.Statement.Declaration declaration ->
      collect_expr_imports declaration.init imports
  | Jir.Statement.Expression expr ->
      collect_expr_imports expr imports

let collect_program_imports = fun program ->
  List.fold_right collect_statement_imports program.Jir.Program.body program.imports

let dedupe_imports = fun imports ->
  let rec loop = fun seen rest ->
    match rest with
    | [] -> List.rev seen
    | import :: rest ->
        let seen_already = List.exists (Imports.equal import) seen in
        if seen_already then
          loop seen rest
        else
          loop (import :: seen) rest
  in
  loop [] imports

let compare_optional_string = fun left right ->
  match (left, right) with
  | (None, None) -> 0
  | (None, Some _) -> -1
  | (Some _, None) -> 1
  | (Some left, Some right) -> String.compare left right

let compare_imports = fun left right ->
  let by_from = String.compare left.Imports.from right.Imports.from in
  if by_from <> 0 then
    by_from
  else
    let by_imported = compare_optional_string left.imported right.imported in
    if by_imported <> 0 then
      by_imported
    else
      String.compare left.local right.local

let program = fun program ->
  let imports =
    collect_program_imports program |> dedupe_imports |> List.sort ~cmp:compare_imports
  in
  { program with imports }
