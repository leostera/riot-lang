open Std
open Std.Data

module Literal = struct
  type number =
    | Int of int
    | Float of float

  type t =
    | Undefined
    | Null
    | Bool of bool
    | Number of number
    | String of string

  let number_to_json = fun number ->
    match number with
    | Int value -> Json.obj [ ("kind", Json.string "int"); ("value", Json.int value); ]
    | Float value -> Json.obj [ ("kind", Json.string "float"); ("value", Json.float value); ]

  let to_json = fun literal ->
    match literal with
    | Undefined -> Json.obj [ ("kind", Json.string "undefined") ]
    | Null -> Json.obj [ ("kind", Json.string "null") ]
    | Bool value -> Json.obj [ ("kind", Json.string "bool"); ("value", Json.bool value); ]
    | Number number -> Json.obj
      [ ("kind", Json.string "number"); ("number", number_to_json number); ]
    | String value -> Json.obj [ ("kind", Json.string "string"); ("value", Json.string value); ]
end

module Expr = struct
  type call = {
    callee: t;
    arguments: t list;
  }

  and t =
    | Literal of Literal.t
    | Identifier of string
    | Imported of Imports.requirement
    | Runtime_helper of Runtime.t
    | Call of call

  let rec call_to_json = fun call ->
    Json.obj
      [
        ("callee", to_json call.callee);
        ("arguments", Json.array (List.map to_json call.arguments));
      ]

  and to_json = fun expr ->
    match expr with
    | Literal literal -> Json.obj
      [ ("kind", Json.string "literal"); ("literal", Literal.to_json literal); ]
    | Identifier name -> Json.obj [ ("kind", Json.string "identifier"); ("name", Json.string name); ]
    | Imported requirement -> Json.obj
      [ ("kind", Json.string "imported"); ("import", Imports.to_json requirement); ]
    | Runtime_helper helper -> Json.obj
      [ ("kind", Json.string "runtime"); ("helper", Runtime.to_json helper); ]
    | Call call -> Json.obj [ ("kind", Json.string "call"); ("call", call_to_json call); ]
end

module Declaration = struct
  type kind =
    | Const
    | Let
    | Var

  type t = {
    kind: kind;
    name: string;
    init: Expr.t;
  }

  let kind_to_json = fun kind ->
    match kind with
    | Const -> Json.string "const"
    | Let -> Json.string "let"
    | Var -> Json.string "var"

  let to_json = fun declaration ->
    Json.obj
      [
        ("kind", kind_to_json declaration.kind);
        ("name", Json.string declaration.name);
        ("init", Expr.to_json declaration.init);
      ]
end

module Statement = struct
  type t =
    | Declaration of Declaration.t
    | Expression of Expr.t

  let to_json = fun statement ->
    match statement with
    | Declaration declaration -> Json.obj
      [ ("kind", Json.string "declaration"); ("declaration", Declaration.to_json declaration); ]
    | Expression expr -> Json.obj
      [ ("kind", Json.string "expression"); ("expression", Expr.to_json expr); ]
end

module Export = struct
  type t = {
    name: string;
    local: string;
  }

  let to_json = fun export ->
    Json.obj [ ("name", Json.string export.name); ("local", Json.string export.local); ]
end

module Program = struct
  type t = {
    module_name: string;
    imports: Imports.requirement list;
    body: Statement.t list;
    exports: Export.t list;
  }

  let empty = fun ~module_name -> { module_name; imports = []; body = []; exports = [] }

  let to_json = fun program ->
    Json.obj
      [
        ("module_name", Json.string program.module_name);
        ("imports", Json.array (List.map Imports.to_json program.imports));
        ("body", Json.array (List.map Statement.to_json program.body));
        ("exports", Json.array (List.map Export.to_json program.exports));
      ]
end
