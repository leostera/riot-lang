open Std.Data

type helper = {
  module_name: string;
  symbol: string;
  local: string;
}
type t = helper

val make: module_name:string -> symbol:string -> ?local:string -> unit -> helper

val to_import: helper -> Imports.requirement

val to_json: helper -> Json.t
