open Std
open Std.Data

type requirement = {
  from: string;
  imported: string option;
  local: string;
}

let make = fun ~from ?imported ~local () -> { from; imported; local }

let equal = fun left right ->
  if String.equal left.from right.from then
    if Option.equal String.equal left.imported right.imported then
      String.equal left.local right.local
    else
      false
  else
    false

let to_json = fun requirement ->
  Json.obj
    [
      ("from", Json.string requirement.from);
      ("imported", Option.map Json.string requirement.imported |> Option.unwrap_or ~default:Json.null);
      ("local", Json.string requirement.local);
    ]
