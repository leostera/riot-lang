open Std
open Std.Data

type helper = {
  module_name: string;
  symbol: string;
  local: string;
}

type t = helper

let make = fun ~module_name ~symbol ?local () ->
  { module_name; symbol; local = Option.unwrap_or ~default:symbol local }

let to_import = fun helper ->
  Imports.make ~from:helper.module_name ~imported:helper.symbol ~local:helper.local ()

let to_json = fun helper ->
  Json.obj
    [
      ("module_name", Json.string helper.module_name);
      ("symbol", Json.string helper.symbol);
      ("local", Json.string helper.local);
    ]
