open Std
open Std.Data

module Literal: sig
  type number =
    | Int of int
    | Float of float
  type t =
    | Undefined
    | Null
    | Bool of bool
    | Number of number
    | String of string
  val number_to_json: number -> Json.t

  val to_json: t -> Json.t
end

module Expr: sig
  type call = {
    callee: t;
    arguments: t list;
  }

  and t =
    | Literal of Literal.t
    | Identifier of string
    | Call of call
  val call_to_json: call -> Json.t

  val to_json: t -> Json.t
end

module Declaration: sig
  type kind =
    | Const
    | Let
    | Var
  type t = {
    kind: kind;
    name: string;
    init: Expr.t;
  }
  val kind_to_json: kind -> Json.t

  val to_json: t -> Json.t
end

module Statement: sig
  type t =
    | Declaration of Declaration.t
    | Expression of Expr.t
  val to_json: t -> Json.t
end

module Import: sig
  type named = {
    imported: string;
    local: string option;
  }
  type t = {
    from: string;
    default: string option;
    names: named list;
  }
  val named_to_json: named -> Json.t

  val to_json: t -> Json.t
end

module Export: sig
  type t = {
    name: string;
    local: string;
  }
  val to_json: t -> Json.t
end

module Module_item: sig
  type t =
    | Import of Import.t
    | Statement of Statement.t
    | Export of Export.t list
  val to_json: t -> Json.t
end

module Program: sig
  type t = {
    module_name: string;
    items: Module_item.t list;
  }
  val empty: module_name:string -> t

  val to_json: t -> Json.t
end
