open Std
open Std.Data

module Literal = struct
  type number =
    | Int of int
    | Float of float

  type t =
    | Undefined
    | Null
    | Bool of bool
    | Number of number
    | String of string

  let number_to_json = fun number ->
    match number with
    | Int value -> Json.obj [ ("kind", Json.string "int"); ("value", Json.int value); ]
    | Float value -> Json.obj [ ("kind", Json.string "float"); ("value", Json.float value); ]

  let to_json = fun literal ->
    match literal with
    | Undefined -> Json.obj [ ("kind", Json.string "undefined") ]
    | Null -> Json.obj [ ("kind", Json.string "null") ]
    | Bool value -> Json.obj [ ("kind", Json.string "bool"); ("value", Json.bool value); ]
    | Number number -> Json.obj
      [ ("kind", Json.string "number"); ("number", number_to_json number); ]
    | String value -> Json.obj [ ("kind", Json.string "string"); ("value", Json.string value); ]
end

module Expr = struct
  type call = {
    callee: t;
    arguments: t list;
  }

  and t =
    | Literal of Literal.t
    | Identifier of string
    | Call of call

  let rec call_to_json = fun call ->
    Json.obj
      [
        ("callee", to_json call.callee);
        ("arguments", Json.array (List.map to_json call.arguments));
      ]

  and to_json = fun expr ->
    match expr with
    | Literal literal -> Json.obj
      [ ("kind", Json.string "literal"); ("literal", Literal.to_json literal); ]
    | Identifier name -> Json.obj [ ("kind", Json.string "identifier"); ("name", Json.string name); ]
    | Call call -> Json.obj [ ("kind", Json.string "call"); ("call", call_to_json call); ]
end

module Declaration = struct
  type kind =
    | Const
    | Let
    | Var

  type t = {
    kind: kind;
    name: string;
    init: Expr.t;
  }

  let kind_to_json = fun kind ->
    match kind with
    | Const -> Json.string "const"
    | Let -> Json.string "let"
    | Var -> Json.string "var"

  let to_json = fun declaration ->
    Json.obj
      [
        ("kind", kind_to_json declaration.kind);
        ("name", Json.string declaration.name);
        ("init", Expr.to_json declaration.init);
      ]
end

module Statement = struct
  type t =
    | Declaration of Declaration.t
    | Expression of Expr.t

  let to_json = fun statement ->
    match statement with
    | Declaration declaration -> Json.obj
      [ ("kind", Json.string "declaration"); ("declaration", Declaration.to_json declaration); ]
    | Expression expr -> Json.obj
      [ ("kind", Json.string "expression"); ("expression", Expr.to_json expr); ]
end

module Import = struct
  type named = {
    imported: string;
    local: string option;
  }

  type t = {
    from: string;
    default: string option;
    names: named list;
  }

  let named_to_json = fun named ->
    Json.obj
      [
        ("imported", Json.string named.imported);
        ("local", Option.map Json.string named.local |> Option.unwrap_or ~default:Json.null);
      ]

  let to_json = fun import ->
    Json.obj
      [
        ("from", Json.string import.from);
        ("default", Option.map Json.string import.default |> Option.unwrap_or ~default:Json.null);
        ("names", Json.array (List.map named_to_json import.names));
      ]
end

module Export = struct
  type t = {
    name: string;
    local: string;
  }

  let to_json = fun export ->
    Json.obj [ ("name", Json.string export.name); ("local", Json.string export.local); ]
end

module Module_item = struct
  type t =
    | Import of Import.t
    | Statement of Statement.t
    | Export of Export.t list

  let to_json = fun item ->
    match item with
    | Import import -> Json.obj
      [ ("kind", Json.string "import"); ("import", Import.to_json import); ]
    | Statement statement -> Json.obj
      [ ("kind", Json.string "statement"); ("statement", Statement.to_json statement); ]
    | Export exports -> Json.obj
      [ ("kind", Json.string "export"); ("exports", Json.array (List.map Export.to_json exports)); ]
end

module Program = struct
  type t = {
    module_name: string;
    items: Module_item.t list;
  }

  let empty = fun ~module_name -> { module_name; items = [] }

  let to_json = fun program ->
    Json.obj
      [
        ("module_name", Json.string program.module_name);
        ("items", Json.array (List.map Module_item.to_json program.items));
      ]
end
