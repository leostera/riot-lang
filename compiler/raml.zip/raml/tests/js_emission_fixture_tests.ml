open Std
open Std.Data
module Jir = Raml.Js.Jir
module Jir_lowering = Raml.Js.Jir.Lowering
module Jst = Raml.Js.Jst

let fixtures_dir = Path.v "compiler/raml/tests/fixtures/js_emission"

let append_snapshot_suffix = fun path suffix ->
  format Format.[ str (Path.to_string (Path.remove_extension path)); str suffix ]
  |> Path.of_string
  |> Result.expect ~msg:"snapshot path should stay valid UTF-8"

let keep_source_fixture = fun path ->
  match Path.extension path with
  | Some ".ml" -> `keep
  | _ -> `skip

let stable_fixture_filename = fun (ctx: Test.FixtureRunner.ctx) ->
  Path.join fixtures_dir ctx.fixture_relpath

let check_source_text = fun ~filename text ->
  let parse_result = Syn.parse ~filename text in
  match Syn.build_cst parse_result with
  | Ok cst -> Typ.Check.check_source ~filename ~parse_result ~cst
  | Error (Syn.Parse_diagnostics diagnostics) -> panic
    (format
      Format.[
        str "expected CST for ";
        str (Path.to_string filename);
        str ": ";
        str (String.concat "; " (List.map Syn.Diagnostic.to_string diagnostics));
      ])
  | Error (Syn.Cst_builder_error error) -> panic
    (format
      Format.[ str "expected CST for "; str (Path.to_string filename); str ": "; str error.message; ])

let render_json = Json.to_string_pretty

let render_typ_lowering_errors = fun errors ->
  Json.array (List.map Raml.Typ_lowering.error_to_json errors) |> render_json

let render_jir_lowering_errors = fun errors ->
  Json.array (List.map Jir_lowering.error_to_json errors) |> render_json

let js_snapshot_to_json = fun ~(jst: Jst.Program.t) ~(output: string) ->
  Json.obj [ ("jst", Jst.Program.to_json jst); ("js", Json.string output) ]

let compile_core_ir = fun (ctx: Test.FixtureRunner.ctx) ->
  let source = Fs.read ctx.fixture_path |> Result.expect ~msg:"fixture should exist" in
  let filename = stable_fixture_filename ctx in
  let report = check_source_text ~filename source in
  let semantic_tree = report.semantic_tree |> Option.expect ~msg:"expected semantic tree" in
  let source_unit = Raml.Source_unit.of_source ~relpath:filename ~source |> Result.expect ~msg:"fixture should produce a supported source unit" in
  match Raml.Typ_lowering.lower_file ~source_unit semantic_tree with
  | Ok compilation_unit -> compilation_unit
  | Error errors -> panic
    (format
      Format.[
        str "expected Typ -> Core IR lowering to succeed:\n";
        str (render_typ_lowering_errors errors);
      ])

let lower_jir = fun compilation_unit ->
  match Jir_lowering.lower_compilation_unit compilation_unit with
  | Ok program -> program
  | Error errors -> panic
    (format
      Format.[
        str "expected Core IR -> JIR lowering to succeed:\n";
        str (render_jir_lowering_errors errors);
      ])

let with_snapshot_path = fun path (ctx: Test.ctx) ->
  let fixture =
    match ctx.fixture with
    | Some fixture -> { fixture with snapshot_path = Some path }
    | None -> panic "expected fixture-backed test context"
  in
  Test.Context.with_fixture ctx fixture

let test_core_ir_fixture = fun ~(ctx:Test.FixtureRunner.ctx) ->
  let compilation_unit = compile_core_ir ctx in
  let snapshot_path = append_snapshot_suffix ctx.fixture_path ".core_ir.expected" in
  Test.Snapshot.assert_json
    ~ctx:(with_snapshot_path snapshot_path ctx.test)
    ~actual:(Raml.Core_ir.Compilation_unit.to_json compilation_unit)

let test_jir_fixture = fun ~(ctx:Test.FixtureRunner.ctx) ->
  let compilation_unit = compile_core_ir ctx in
  let program = lower_jir compilation_unit in
  let snapshot_path = append_snapshot_suffix ctx.fixture_path ".jir.expected" in
  Test.Snapshot.assert_json
    ~ctx:(with_snapshot_path snapshot_path ctx.test)
    ~actual:(Jir.Program.to_json program)

let test_js_fixture = fun ~(ctx:Test.FixtureRunner.ctx) ->
  let compilation_unit = compile_core_ir ctx in
  let program = lower_jir compilation_unit in
  let snapshot_path = append_snapshot_suffix ctx.fixture_path ".js.expected" in
  let jst = Jst.Lowering.lower_program program in
  let output = Jst.Emitter.emit_program jst in
  let actual = js_snapshot_to_json ~jst ~output in
  Test.Snapshot.assert_json ~ctx:(with_snapshot_path snapshot_path ctx.test) ~actual

let () =
  Actors.run
    ~main:(fun ~args ->
      let core_ir_tests =
        Test.FixtureRunner.cases
          ()
          ~dir:fixtures_dir
          ~filter:keep_source_fixture
          ~run:(fun ctx -> test_core_ir_fixture ~ctx)
      in
      let jir_tests =
        Test.FixtureRunner.cases
          ()
          ~dir:fixtures_dir
          ~filter:keep_source_fixture
          ~run:(fun ctx -> test_jir_fixture ~ctx)
      in
      let js_tests =
        Test.FixtureRunner.cases
          ()
          ~dir:fixtures_dir
          ~filter:keep_source_fixture
          ~run:(fun ctx -> test_js_fixture ~ctx)
      in
      Test.Cli.main
        ~name:"raml:js_emission_fixture_tests"
        ~tests:(core_ir_tests @ jir_tests @ js_tests)
        ~args)
    ~args:Env.args
    ()
