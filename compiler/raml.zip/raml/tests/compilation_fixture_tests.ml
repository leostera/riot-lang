open Std

let fixtures_dir = Path.v "compiler/raml/tests/fixtures/examples"

let logical_examples_dir = Path.v "examples"

let append_snapshot_suffix = fun path suffix ->
  format Format.[ str (Path.to_string (Path.remove_extension path)); str suffix ]
  |> Path.of_string
  |> Result.expect ~msg:"snapshot path should stay valid UTF-8"

let keep_source_fixture = fun path ->
  match Path.extension path with
  | Some ".ml" -> `keep
  | _ -> `skip

let stable_fixture_filename = fun (ctx: Test.FixtureRunner.ctx) ->
  Path.join logical_examples_dir ctx.fixture_relpath

let with_snapshot_path = fun path (ctx: Test.ctx) ->
  let fixture =
    match ctx.fixture with
    | Some fixture -> { fixture with snapshot_path = Some path }
    | None -> panic "expected fixture-backed test context"
  in
  Test.Context.with_fixture ctx fixture

let compile_fixture = fun (ctx: Test.FixtureRunner.ctx) ->
  let source = Fs.read ctx.fixture_path |> Result.expect ~msg:"fixture should exist" in
  let filename = stable_fixture_filename ctx in
  let config = Raml.Config.make
    ~host:Raml.Target.aarch64_apple_darwin
    ~target:Raml.Target.js_unknown_ecma
    () in
  Raml.compile_source ~config ~relpath:filename source |> Result.expect ~msg:"fixture should compile into a backend-oriented compilation snapshot"

let test_compilation_fixture = fun ~(ctx:Test.FixtureRunner.ctx) ->
  let snapshot_path = append_snapshot_suffix ctx.fixture_path ".compilation.expected" in
  let actual = compile_fixture ctx |> Raml.Compilation.to_json in
  Test.Snapshot.assert_json ~ctx:(with_snapshot_path snapshot_path ctx.test) ~actual

let () =
  Actors.run
    ~main:(fun ~args ->
      let tests =
        Test.FixtureRunner.cases
          ()
          ~dir:fixtures_dir
          ~filter:keep_source_fixture
          ~run:(fun ctx -> test_compilation_fixture ~ctx)
      in
      Test.Cli.main ~name:"raml:compilation_fixture_tests" ~tests ~args)
    ~args:Env.args
    ()
