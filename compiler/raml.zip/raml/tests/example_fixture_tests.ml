open Std

let fixtures_dir = Path.v "compiler/raml/tests/fixtures/examples"

let logical_examples_dir = Path.v "examples"

let append_snapshot_suffix = fun path suffix ->
  format Format.[ str (Path.to_string (Path.remove_extension path)); str suffix ]
  |> Path.of_string
  |> Result.expect ~msg:"snapshot path should stay valid UTF-8"

let keep_source_fixture = fun path ->
  match Path.extension path with
  | Some ".ml" -> `keep
  | _ -> `skip

let stable_fixture_filename = fun (ctx: Test.FixtureRunner.ctx) ->
  Path.join logical_examples_dir ctx.fixture_relpath

let with_snapshot_path = fun path (ctx: Test.ctx) ->
  let fixture =
    match ctx.fixture with
    | Some fixture -> { fixture with snapshot_path = Some path }
    | None -> panic "expected fixture-backed test context"
  in
  Test.Context.with_fixture ctx fixture

let compile_fixture = fun (ctx: Test.FixtureRunner.ctx) ->
  let source = Fs.read ctx.fixture_path |> Result.expect ~msg:"fixture should exist" in
  let filename = stable_fixture_filename ctx in
  Raml.Example_pipeline.compile_source
    ~host:Raml.Target.aarch64_apple_darwin
    ~target:Raml.Target.js_unknown_ecma
    ~relpath:filename
    ~source
  |> Result.expect ~msg:"fixture should compile into a pipeline snapshot"

let test_pipeline_fixture = fun ~(ctx:Test.FixtureRunner.ctx) ->
  let snapshot_path = append_snapshot_suffix ctx.fixture_path ".pipeline.expected" in
  let actual = compile_fixture ctx |> Raml.Example_pipeline.to_json in
  Test.Snapshot.assert_json ~ctx:(with_snapshot_path snapshot_path ctx.test) ~actual

let test_lowering_fixture = fun ~(ctx:Test.FixtureRunner.ctx) ->
  let snapshot_path = append_snapshot_suffix ctx.fixture_path ".lowering.expected" in
  let actual = compile_fixture ctx |> Raml.Example_pipeline.lowering_to_json in
  Test.Snapshot.assert_json ~ctx:(with_snapshot_path snapshot_path ctx.test) ~actual

let test_codegen_fixture = fun ~(ctx:Test.FixtureRunner.ctx) ->
  let snapshot_path = append_snapshot_suffix ctx.fixture_path ".codegen.expected" in
  let actual = compile_fixture ctx |> Raml.Example_pipeline.codegen_to_json in
  Test.Snapshot.assert_json ~ctx:(with_snapshot_path snapshot_path ctx.test) ~actual

let () =
  Actors.run
    ~main:(fun ~args ->
      let pipeline_tests =
        Test.FixtureRunner.cases
          ()
          ~dir:fixtures_dir
          ~filter:keep_source_fixture
          ~run:(fun ctx -> test_pipeline_fixture ~ctx)
      in
      let lowering_tests =
        Test.FixtureRunner.cases
          ()
          ~dir:fixtures_dir
          ~filter:keep_source_fixture
          ~run:(fun ctx -> test_lowering_fixture ~ctx)
      in
      let codegen_tests =
        Test.FixtureRunner.cases
          ()
          ~dir:fixtures_dir
          ~filter:keep_source_fixture
          ~run:(fun ctx -> test_codegen_fixture ~ctx)
      in
      Test.Cli.main
        ~name:"raml:example_fixture_tests"
        ~tests:(pipeline_tests @ lowering_tests @ codegen_tests)
        ~args)
    ~args:Env.args
    ()
