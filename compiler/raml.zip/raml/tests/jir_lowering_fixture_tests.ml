open Std
open Std.Data
module Jir = Raml.Js.Jir
module Jir_lowering = Raml.Js.Jir.Lowering

let ( let* ) = Result.and_then

let fixtures_dir = Path.v "compiler/raml/tests/fixtures/jir_lowering"

let keep_json = fun path ->
  match Path.extension path with
  | Some ".json" -> `keep
  | _ -> `skip

let lowering_result_to_json = fun result ->
  match result with
  | Ok program -> Json.obj
    [ ("status", Json.string "ok"); ("program", Jir.Program.to_json program); ]
  | Error errors -> Json.obj
    [
      ("status", Json.string "error");
      ("errors", Json.array (List.map Jir_lowering.error_to_json errors));
    ]

let test_fixture = fun ~(ctx:Test.FixtureRunner.ctx) ->
  let* source = Result.map_error IO.error_message (Fs.read ctx.fixture_path) in
  let* json = Result.map_error Json.error_to_string (Json.of_string source) in
  let* compilation_unit = Raml.Core_ir_fixture_support.parse_compilation_unit json in
  let actual = Jir_lowering.lower_compilation_unit compilation_unit |> lowering_result_to_json in
  Test.Snapshot.assert_json ~ctx:ctx.test ~actual

let () =
  Actors.run
    ~main:(fun ~args ->
      let tests =
        Test.FixtureRunner.cases
          ()
          ~dir:fixtures_dir
          ~filter:keep_json
          ~run:(fun ctx -> test_fixture ~ctx)
      in
      Test.Cli.main ~name:"raml:jir_lowering_fixture_tests" ~tests ~args)
    ~args:Env.args
    ()
