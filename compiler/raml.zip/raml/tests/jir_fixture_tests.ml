open Std
open Std.Data
module Jir = Raml.Js.Jir

let ( let* ) = Result.and_then

let fixtures_dir = Path.v "compiler/raml/tests/fixtures/jir"

let keep_json = fun path ->
  match Path.extension path with
  | Some ".json" -> `keep
  | _ -> `skip

let missing_field = fun scope field ->
  Error (format Format.[ str scope; str " is missing field `"; str field; str "`" ])

let invalid_field = fun scope field expected ->
  Error (format Format.[ str scope; str "."; str field; str " must be "; str expected ])

let map_results = fun items f ->
  List.fold_right
    (fun item acc ->
      let* item = f item in
      let* acc = acc in
      Ok (item :: acc))
    items
    (Ok [])

let field = fun scope name json ->
  match Json.get_field name json with
  | Some value -> Ok value
  | None -> missing_field scope name

let string_field = fun scope name json ->
  let* value = field scope name json in
  match Json.get_string value with
  | Some value -> Ok value
  | None -> invalid_field scope name "a string"

let array_field = fun scope name json ->
  let* value = field scope name json in
  match Json.get_array value with
  | Some value -> Ok value
  | None -> invalid_field scope name "an array"

let float_of_json = fun json ->
  match json with
  | Json.Float value -> Some value
  | Json.Int value -> Some (float_of_int value)
  | _ -> None

let parse_number = fun json ->
  let scope = "number" in
  let* kind = string_field scope "kind" json in
  match kind with
  | "int" ->
      let* value = field scope "value" json in
      let value =
        match Json.get_int value with
        | Some value -> Ok value
        | None -> invalid_field scope "value" "an integer"
      in
      Result.map (fun value -> Jir.Literal.Int value) value
  | "float" ->
      let* value = field scope "value" json in
      let value =
        match float_of_json value with
        | Some value -> Ok value
        | None -> invalid_field scope "value" "a number"
      in
      Result.map (fun value -> Jir.Literal.Float value) value
  | _ ->
      invalid_field scope "kind" "`int` or `float`"

let parse_literal = fun json ->
  let scope = "literal" in
  let* kind = string_field scope "kind" json in
  match kind with
  | "undefined" ->
      Ok Jir.Literal.Undefined
  | "null" ->
      Ok Jir.Literal.Null
  | "bool" ->
      let* value = field scope "value" json in
      let value =
        match Json.get_bool value with
        | Some value -> Ok value
        | None -> invalid_field scope "value" "a boolean"
      in
      Result.map (fun value -> Jir.Literal.Bool value) value
  | "number" ->
      let* number_json = field scope "number" json in
      let* number = parse_number number_json in
      Ok (Jir.Literal.Number number)
  | "string" ->
      let* value = string_field scope "value" json in
      Ok (Jir.Literal.String value)
  | _ ->
      invalid_field scope "kind" "`undefined`, `null`, `bool`, `number`, or `string`"

let parse_import = fun json ->
  let scope = "import" in
  let* from = string_field scope "from" json in
  let imported =
    match Json.get_field "imported" json with
    | None | Some Json.Null -> Ok None
    | Some value -> (
        match Json.get_string value with
        | Some value -> Ok (Some value)
        | None -> invalid_field scope "imported" "a string or null"
      )
  in
  let* imported = imported in
  let* local = string_field scope "local" json in
  Ok (Jir.Import.make ~from ?imported ~local ())

let parse_runtime = fun json ->
  let scope = "runtime" in
  let* module_name = string_field scope "module_name" json in
  let* symbol = string_field scope "symbol" json in
  let* local = string_field scope "local" json in
  Ok (Jir.Runtime.make ~module_name ~symbol ~local ())

let rec parse_expr = fun json ->
  let scope = "expr" in
  let* kind = string_field scope "kind" json in
  match kind with
  | "literal" ->
      let* literal_json = field scope "literal" json in
      let* literal = parse_literal literal_json in
      Ok (Jir.Expr.Literal literal)
  | "identifier" ->
      let* name = string_field scope "name" json in
      Ok (Jir.Expr.Identifier name)
  | "imported" ->
      let* import_json = field scope "import" json in
      let* import = parse_import import_json in
      Ok (Jir.Expr.Imported import)
  | "runtime" ->
      let* helper_json = field scope "helper" json in
      let* helper = parse_runtime helper_json in
      Ok (Jir.Expr.Runtime helper)
  | "call" ->
      let* call_json = field scope "call" json in
      let* call = parse_call call_json in
      Ok (Jir.Expr.Call call)
  | _ ->
      invalid_field scope "kind" "`literal`, `identifier`, `imported`, `runtime`, or `call`"

and parse_call = fun json ->
  let scope = "call" in
  let* callee_json = field scope "callee" json in
  let* callee = parse_expr callee_json in
  let* arguments = array_field scope "arguments" json in
  let* arguments = map_results arguments parse_expr in
  Ok Jir.Expr.{ callee; arguments }

let parse_declaration_kind = fun json ->
  let scope = "declaration" in
  let* kind = string_field scope "kind" json in
  match kind with
  | "const" -> Ok Jir.Declaration.Const
  | "let" -> Ok Jir.Declaration.Let
  | "var" -> Ok Jir.Declaration.Var
  | _ -> invalid_field scope "kind" "`const`, `let`, or `var`"

let parse_declaration = fun json ->
  let scope = "declaration" in
  let* kind = parse_declaration_kind json in
  let* name = string_field scope "name" json in
  let* init_json = field scope "init" json in
  let* init = parse_expr init_json in
  Ok Jir.Declaration.{ kind; name; init }

let parse_statement = fun json ->
  let scope = "statement" in
  let* kind = string_field scope "kind" json in
  match kind with
  | "declaration" ->
      let* declaration_json = field scope "declaration" json in
      let* declaration = parse_declaration declaration_json in
      Ok (Jir.Statement.Declaration declaration)
  | "expression" ->
      let* expression_json = field scope "expression" json in
      let* expression = parse_expr expression_json in
      Ok (Jir.Statement.Expression expression)
  | _ ->
      invalid_field scope "kind" "`declaration` or `expression`"

let parse_export = fun json ->
  let scope = "export" in
  let* name = string_field scope "name" json in
  let* local = string_field scope "local" json in
  Ok Jir.Export.{ name; local }

let parse_program = fun json ->
  let* module_name = string_field "program" "module_name" json in
  let imports =
    match Json.get_field "imports" json with
    | None -> Ok []
    | Some value -> (
        match Json.get_array value with
        | Some imports -> map_results imports parse_import
        | None -> invalid_field "program" "imports" "an array"
      )
  in
  let* imports = imports in
  let* body = array_field "program" "body" json in
  let* body = map_results body parse_statement in
  let* exports = array_field "program" "exports" json in
  let* exports = map_results exports parse_export in
  Ok Jir.Program.{ module_name; imports; body; exports }

let test_fixture = fun ~(ctx:Test.FixtureRunner.ctx) ->
  let* source = Result.map_error IO.error_message (Fs.read ctx.fixture_path) in
  let* json = Result.map_error Json.error_to_string (Json.of_string source) in
  let* program = parse_program json in
  Test.Snapshot.assert_json ~ctx:ctx.test ~actual:(Jir.Program.to_json program)

let () =
  Actors.run
    ~main:(fun ~args ->
      let tests =
        Test.FixtureRunner.cases
          ()
          ~dir:fixtures_dir
          ~filter:keep_json
          ~run:(fun ctx -> test_fixture ~ctx)
      in
      Test.Cli.main ~name:"raml:jir_fixture_tests" ~tests ~args)
    ~args:Env.args
    ()
