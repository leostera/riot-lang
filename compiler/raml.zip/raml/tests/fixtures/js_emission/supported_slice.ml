let answer = 41

let ready = true

let ratio = 3.5

let label = "done"

let next = succ answer

let nothing = ()
