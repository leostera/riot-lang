let answer = 42
