#![allow(dead_code)]

use crate::ast::{AstBlock, AstDecl, AstExpr, AstFnDecl, AstPath, AstProgram, AstStmt};
use crate::signature::{Rsig, RsigExternal, RsigExport, RsigFunction, RsigType, parse_type_signature};

#[derive(Debug, Clone)]
pub(crate) struct CheckedProgram {
    pub(crate) typed_tree: TypedProgram,
    pub(crate) signature: Rsig,
}

#[derive(Debug, Clone)]
pub(crate) struct TypedProgram {
    pub(crate) module_name: String,
    pub(crate) uses: Vec<TypedUse>,
    pub(crate) externals: Vec<TypedExternal>,
    pub(crate) functions: Vec<TypedFunction>,
}

#[derive(Debug, Clone)]
pub(crate) struct TypedUse {
    pub(crate) name: String,
}

#[derive(Debug, Clone)]
pub(crate) struct TypedExternal {
    pub(crate) name: String,
    pub(crate) type_text: String,
    pub(crate) params: Vec<RsigType>,
    pub(crate) result: RsigType,
    pub(crate) abi: String,
}

#[derive(Debug, Clone)]
pub(crate) struct TypedFunction {
    pub(crate) name: String,
    pub(crate) params: Vec<String>,
    pub(crate) body: AstBlock,
    pub(crate) symbol: String,
}

#[derive(Debug, Clone)]
pub(crate) struct RirProgram {
    pub(crate) module_name: String,
    pub(crate) uses: Vec<String>,
    pub(crate) externals: Vec<RirExternal>,
    pub(crate) functions: Vec<RirFunction>,
}

#[derive(Debug, Clone)]
pub(crate) struct RirExternal {
    pub(crate) name: String,
    pub(crate) params: Vec<RsigType>,
    pub(crate) result: RsigType,
    pub(crate) abi: String,
}

#[derive(Debug, Clone)]
pub(crate) struct RirFunction {
    pub(crate) name: String,
    pub(crate) params: Vec<String>,
    pub(crate) body: RirBlock,
    pub(crate) symbol: String,
}

#[derive(Debug, Clone)]
pub(crate) struct RirBlock {
    pub(crate) statements: Vec<RirStmt>,
    pub(crate) tail: Option<RirExpr>,
}

#[derive(Debug, Clone)]
pub(crate) enum RirStmt {
    Let {
        name: String,
        value: RirExpr,
    },
    Expr(RirExpr),
}

#[derive(Debug, Clone)]
pub(crate) enum RirExpr {
    Add(Box<RirExpr>, Box<RirExpr>),
    Sub(Box<RirExpr>, Box<RirExpr>),
    Mul(Box<RirExpr>, Box<RirExpr>),
    Div(Box<RirExpr>, Box<RirExpr>),
    Mod(Box<RirExpr>, Box<RirExpr>),
    Neg(Box<RirExpr>),
    Eq(Box<RirExpr>, Box<RirExpr>),
    Lt(Box<RirExpr>, Box<RirExpr>),
    And(Box<RirExpr>, Box<RirExpr>),
    Or(Box<RirExpr>, Box<RirExpr>),
    Not(Box<RirExpr>),
    If {
        condition: Box<RirExpr>,
        then_branch: Box<RirExpr>,
        else_branch: Box<RirExpr>,
    },
    Bool(bool),
    Call {
        callee: Vec<String>,
        args: Vec<RirExpr>,
    },
    Unit,
    Tuple(Vec<RirExpr>),
    List(Vec<RirExpr>),
    Record {
        path: Vec<String>,
        fields: Vec<(String, RirExpr)>,
    },
    Char(char),
    Float(String),
    Int(i64),
    Path(Vec<String>),
    String(String),
    Spawn {
        body: Box<RirBlock>,
    },
    Receive {
        binder: String,
        body: Box<RirExpr>,
    },
}

#[derive(Debug, Clone)]
pub(crate) struct ActorIrProgram {
    pub(crate) module_name: String,
    pub(crate) instructions: Vec<ActorIrInstruction>,
}

#[derive(Debug, Clone)]
pub(crate) enum ActorIrInstruction {
    SpawnActor { binding: String, program: ActorFrameProgram },
    ExternalCall { function: String, args: Vec<RirExpr> },
    Expr(RirExpr),
}

#[derive(Debug, Clone)]
pub(crate) struct ActorFrameProgram {
    pub(crate) instructions: Vec<ActorFrameInstruction>,
}

#[derive(Debug, Clone)]
pub(crate) enum ActorFrameInstruction {
    Let { name: String, value: RirExpr },
    Receive { binder: String, body: RirExpr },
    Expr(RirExpr),
}

pub(crate) fn typed_program_from_ast(module_name: String, ast: AstProgram) -> TypedProgram {
    let mut uses = Vec::new();
    let mut externals = Vec::new();
    let mut functions = Vec::new();

    for decl in ast.decls {
        match decl {
            AstDecl::Use(use_) => uses.push(TypedUse { name: use_.name }),
            AstDecl::External(external) => {
                let (params, result) = parse_type_signature(&external.type_text);
                externals.push(TypedExternal {
                    name: external.name,
                    type_text: external.type_text,
                    params,
                    result,
                    abi: external.abi,
                });
            }
            AstDecl::Function(function) => {
                let symbol = module_function_symbol(&module_name, &function.name);
                functions.push(TypedFunction {
                    name: function.name,
                    params: function.params,
                    body: function.body,
                    symbol,
                });
            }
        }
    }

    TypedProgram {
        module_name,
        uses,
        externals,
        functions,
    }
}

pub(crate) fn signature_for(program: &TypedProgram) -> Rsig {
    let mut exports = Vec::new();
    for function in &program.functions {
        if function.name == "main" {
            continue;
        }
        exports.push(RsigExport::Function(RsigFunction {
            name: function.name.clone(),
            params: function.params.iter().map(|_| RsigType::Unknown).collect(),
            result: RsigType::Unknown,
            symbol: function.symbol.clone(),
            fingerprint: 0,
        }));
    }
    for external in &program.externals {
        exports.push(RsigExport::External(RsigExternal {
            name: external.name.clone(),
            params: external.params.clone(),
            result: external.result.clone(),
            abi: external.abi.clone(),
            fingerprint: 0,
        }));
    }
    Rsig::new(program.module_name.clone(), exports)
}

pub(crate) fn lower_typed_to_rir(program: TypedProgram) -> RirProgram {
    RirProgram {
        module_name: program.module_name,
        uses: program.uses.into_iter().map(|use_| use_.name).collect(),
        externals: program
            .externals
            .into_iter()
            .map(|external| RirExternal {
                name: external.name,
                params: external.params,
                result: external.result,
                abi: external.abi,
            })
            .collect(),
        functions: program
            .functions
            .into_iter()
            .map(|function| RirFunction {
                name: function.name,
                params: function.params,
                body: lower_block(function.body),
                symbol: function.symbol,
            })
            .collect(),
    }
}

pub(crate) fn lower_rir_to_actor_ir(program: &RirProgram) -> ActorIrProgram {
    let mut instructions = Vec::new();
    if let Some(main) = program.functions.iter().find(|function| function.name == "main") {
        collect_actor_ir_from_block(&main.body, &mut instructions);
    }
    ActorIrProgram {
        module_name: program.module_name.clone(),
        instructions,
    }
}

pub(crate) fn module_function_symbol(module: &str, name: &str) -> String {
    format!("riot_mod_{module}_{name}")
}

fn collect_actor_ir_from_block(block: &RirBlock, instructions: &mut Vec<ActorIrInstruction>) {
    for stmt in &block.statements {
        match stmt {
            RirStmt::Let {
                name,
                value: RirExpr::Spawn { body },
            } => instructions.push(ActorIrInstruction::SpawnActor {
                binding: name.clone(),
                program: actor_frame_from_block(body),
            }),
            RirStmt::Expr(RirExpr::Call { callee, args }) if callee.len() == 1 => {
                instructions.push(ActorIrInstruction::ExternalCall {
                    function: callee[0].clone(),
                    args: args.clone(),
                });
            }
            RirStmt::Expr(expr) => instructions.push(ActorIrInstruction::Expr(expr.clone())),
            RirStmt::Let { .. } => {}
        }
    }
    if let Some(RirExpr::Call { callee, args }) = &block.tail
        && callee.len() == 1
    {
        instructions.push(ActorIrInstruction::ExternalCall {
            function: callee[0].clone(),
            args: args.clone(),
        });
    }
}

fn actor_frame_from_block(block: &RirBlock) -> ActorFrameProgram {
    let mut instructions = Vec::new();
    for stmt in &block.statements {
        match stmt {
            RirStmt::Let { name, value } => instructions.push(ActorFrameInstruction::Let {
                name: name.clone(),
                value: value.clone(),
            }),
            RirStmt::Expr(RirExpr::Receive { binder, body }) => {
                instructions.push(ActorFrameInstruction::Receive {
                    binder: binder.clone(),
                    body: *body.clone(),
                });
            }
            RirStmt::Expr(expr) => instructions.push(ActorFrameInstruction::Expr(expr.clone())),
        }
    }
    if let Some(expr) = &block.tail {
        match expr {
            RirExpr::Receive { binder, body } => {
                instructions.push(ActorFrameInstruction::Receive {
                    binder: binder.clone(),
                    body: *body.clone(),
                });
            }
            expr => instructions.push(ActorFrameInstruction::Expr(expr.clone())),
        }
    }
    ActorFrameProgram { instructions }
}

fn lower_block(block: AstBlock) -> RirBlock {
    RirBlock {
        statements: block
            .statements
            .into_iter()
            .map(|stmt| match stmt {
                AstStmt::Let {
                    name,
                    name_span: _,
                    type_annotation: _,
                    value,
                    span: _,
                } => RirStmt::Let {
                    name,
                    value: lower_expr(value),
                },
                AstStmt::Expr(expr) => RirStmt::Expr(lower_expr(expr)),
            })
            .collect(),
        tail: block.tail.map(lower_expr),
    }
}

fn lower_expr(expr: AstExpr) -> RirExpr {
    match expr {
        AstExpr::Add { lhs, rhs, span: _ } => {
            RirExpr::Add(Box::new(lower_expr(*lhs)), Box::new(lower_expr(*rhs)))
        }
        AstExpr::Sub { lhs, rhs, span: _ } => {
            RirExpr::Sub(Box::new(lower_expr(*lhs)), Box::new(lower_expr(*rhs)))
        }
        AstExpr::Mul { lhs, rhs, span: _ } => {
            RirExpr::Mul(Box::new(lower_expr(*lhs)), Box::new(lower_expr(*rhs)))
        }
        AstExpr::Div { lhs, rhs, span: _ } => {
            RirExpr::Div(Box::new(lower_expr(*lhs)), Box::new(lower_expr(*rhs)))
        }
        AstExpr::Mod { lhs, rhs, span: _ } => {
            RirExpr::Mod(Box::new(lower_expr(*lhs)), Box::new(lower_expr(*rhs)))
        }
        AstExpr::Neg { expr, span: _ } => RirExpr::Neg(Box::new(lower_expr(*expr))),
        AstExpr::Eq { lhs, rhs, span: _ } => {
            RirExpr::Eq(Box::new(lower_expr(*lhs)), Box::new(lower_expr(*rhs)))
        }
        AstExpr::Lt { lhs, rhs, span: _ } => {
            RirExpr::Lt(Box::new(lower_expr(*lhs)), Box::new(lower_expr(*rhs)))
        }
        AstExpr::And { lhs, rhs, span: _ } => {
            RirExpr::And(Box::new(lower_expr(*lhs)), Box::new(lower_expr(*rhs)))
        }
        AstExpr::Or { lhs, rhs, span: _ } => {
            RirExpr::Or(Box::new(lower_expr(*lhs)), Box::new(lower_expr(*rhs)))
        }
        AstExpr::Not { expr, span: _ } => RirExpr::Not(Box::new(lower_expr(*expr))),
        AstExpr::If {
            condition,
            then_branch,
            else_branch,
            span: _,
        } => RirExpr::If {
            condition: Box::new(lower_expr(*condition)),
            then_branch: Box::new(lower_expr(*then_branch)),
            else_branch: Box::new(lower_expr(*else_branch)),
        },
        AstExpr::Bool { value, span: _ } => RirExpr::Bool(value),
        AstExpr::Call {
            callee,
            args,
            span: _,
        } => RirExpr::Call {
            callee: callee.segments,
            args: args.into_iter().map(lower_expr).collect(),
        },
        AstExpr::Spawn { body, span: _ } => RirExpr::Spawn {
            body: Box::new(lower_block(*body)),
        },
        AstExpr::Receive {
            binder,
            binder_span: _,
            body,
            span: _,
        } => RirExpr::Receive {
            binder,
            body: Box::new(lower_expr(*body)),
        },
        AstExpr::Unit { span: _ } => RirExpr::Unit,
        AstExpr::Tuple { items, span: _ } => {
            RirExpr::Tuple(items.into_iter().map(lower_expr).collect())
        }
        AstExpr::List { items, span: _ } => RirExpr::List(items.into_iter().map(lower_expr).collect()),
        AstExpr::Record {
            path,
            fields,
            span: _,
        } => RirExpr::Record {
            path: path.segments,
            fields: fields
                .into_iter()
                .map(|(name, value)| (name, lower_expr(value)))
                .collect(),
        },
        AstExpr::Char { value, span: _ } => RirExpr::Char(value),
        AstExpr::Float { value, span: _ } => RirExpr::Float(value),
        AstExpr::Int { value, span: _ } => RirExpr::Int(value),
        AstExpr::Path { path, span: _ } => RirExpr::Path(path.segments),
        AstExpr::String { value, span: _ } => RirExpr::String(value),
    }
}

#[allow(dead_code)]
fn _keep_ast_path_used(_: &AstPath, _: &AstFnDecl) {}
