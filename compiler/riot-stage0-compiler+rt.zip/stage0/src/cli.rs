use camino::Utf8PathBuf;
use clap::{Parser as ClapParser, Subcommand, ValueEnum};

#[derive(Debug, ClapParser)]
#[command(name = "stage0")]
#[command(about = "Riot ML stage0 compiler")]
pub(crate) struct Cli {
    #[command(subcommand)]
    pub(crate) command: Command,
}

#[derive(Debug, Subcommand)]
pub(crate) enum Command {
    /// Compile one Riot ML source file to a native executable.
    Compile(CompileArgs),
    /// Emit one compiler pipeline artifact.
    Emit(EmitArgs),
}

#[derive(Debug, ClapParser)]
pub(crate) struct CompileArgs {
    /// Riot ML .ml source file to compile.
    pub(crate) input: Utf8PathBuf,

    /// Output executable path.
    #[arg(short, long)]
    pub(crate) output: Utf8PathBuf,

    /// Directory to search for imported .rsig files.
    #[arg(long = "sig-dir")]
    pub(crate) sig_dirs: Vec<Utf8PathBuf>,

    /// Directory to search for imported module object files.
    #[arg(long = "object-dir")]
    pub(crate) object_dirs: Vec<Utf8PathBuf>,

    /// Imported module object mapping, for example Math=build/Math.o.
    #[arg(long = "object", value_parser = parse_object_mapping)]
    pub(crate) objects: Vec<ObjectMapping>,

    /// Also write the generated LLVM IR to this path.
    #[arg(long)]
    pub(crate) emit_llvm: Option<Utf8PathBuf>,
}

#[derive(Debug, ClapParser)]
pub(crate) struct EmitArgs {
    /// Compiler pass to emit.
    #[arg(value_enum)]
    pub(crate) pass: EmitPass,

    /// Riot ML .ml source file to inspect.
    pub(crate) input: Utf8PathBuf,

    /// Output path. Defaults to stdout for text passes and <input>.rsig for rsig.
    #[arg(short, long)]
    pub(crate) output: Option<Utf8PathBuf>,

    /// Directory to search for imported .rsig files.
    #[arg(long = "sig-dir")]
    pub(crate) sig_dirs: Vec<Utf8PathBuf>,
}

#[derive(Debug, Clone, Copy, ValueEnum, PartialEq, Eq)]
pub(crate) enum EmitPass {
    Cst,
    Typed,
    Rsig,
    Ir,
    ActorIr,
    Llvm,
    Assembly,
    All,
}

#[derive(Debug, Clone)]
pub(crate) struct ObjectMapping {
    pub(crate) module: String,
    pub(crate) path: Utf8PathBuf,
}

fn parse_object_mapping(value: &str) -> Result<ObjectMapping, String> {
    let Some((module, path)) = value.split_once('=') else {
        return Err("expected NAME=PATH".to_owned());
    };
    if module.is_empty() {
        return Err("object mapping module name cannot be empty".to_owned());
    }
    Ok(ObjectMapping {
        module: module.to_owned(),
        path: Utf8PathBuf::from(path),
    })
}
