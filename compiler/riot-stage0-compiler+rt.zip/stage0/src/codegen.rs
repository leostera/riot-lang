use std::collections::HashMap;

use camino::Utf8Path;
use inkwell::AddressSpace;
use inkwell::OptimizationLevel;
use inkwell::context::Context;
use inkwell::module::Module;
use inkwell::targets::{
    CodeModel, FileType, InitializationConfig, RelocMode, Target, TargetMachine,
};
use miette::bail;

use crate::ir::{RirBlock, RirExpr, RirFunction, RirProgram, RirStmt};

pub(crate) fn emit_object(
    program: &RirProgram,
    object_path: &Utf8Path,
    llvm_ir_path: Option<&Utf8Path>,
) -> miette::Result<()> {
    let outputs = evaluate_outputs(program)?;
    let context = Context::create();
    let target_machine = create_target_machine()?;
    let module = build_output_module(&context, &target_machine, &outputs)?;

    if let Some(path) = llvm_ir_path {
        module
            .print_to_file(path.as_std_path())
            .map_err(|error| miette::miette!("failed to write LLVM IR: {error}"))?;
    }

    target_machine
        .write_to_file(&module, FileType::Object, object_path.as_std_path())
        .map_err(|error| miette::miette!("failed to emit object file: {error}"))?;

    Ok(())
}

pub(crate) fn emit_llvm_text(program: &RirProgram) -> miette::Result<String> {
    let outputs = evaluate_outputs(program)?;
    let context = Context::create();
    let target_machine = create_target_machine()?;
    let module = build_output_module(&context, &target_machine, &outputs)?;
    Ok(module.print_to_string().to_string())
}

pub(crate) fn emit_assembly_text(program: &RirProgram) -> miette::Result<String> {
    let outputs = evaluate_outputs(program)?;
    let context = Context::create();
    let target_machine = create_target_machine()?;
    let module = build_output_module(&context, &target_machine, &outputs)?;
    let buffer = target_machine
        .write_to_memory_buffer(&module, FileType::Assembly)
        .map_err(|error| miette::miette!("failed to emit assembly: {error}"))?;
    Ok(String::from_utf8_lossy(buffer.as_slice()).into_owned())
}

fn create_target_machine() -> miette::Result<TargetMachine> {
    Target::initialize_native(&InitializationConfig::default())
        .map_err(|error| miette::miette!("failed to initialize native LLVM target: {error}"))?;

    let triple = TargetMachine::get_default_triple();
    let target = Target::from_triple(&triple)
        .map_err(|error| miette::miette!("failed to load LLVM target: {error}"))?;
    target
        .create_target_machine(
            &triple,
            "generic",
            "",
            OptimizationLevel::Default,
            RelocMode::Default,
            CodeModel::Default,
        )
        .ok_or_else(|| miette::miette!("failed to create LLVM target machine"))
}

fn build_output_module<'ctx>(
    context: &'ctx Context,
    target_machine: &TargetMachine,
    outputs: &[String],
) -> miette::Result<Module<'ctx>> {
    let triple = TargetMachine::get_default_triple();
    let module = context.create_module("stage0_main");
    module.set_triple(&triple);
    module.set_data_layout(&target_machine.get_target_data().get_data_layout());

    let builder = context.create_builder();
    let i32_type = context.i32_type();
    let i64_type = context.i64_type();
    let void_type = context.void_type();
    let ptr_type = context.ptr_type(AddressSpace::default());

    let init_fn = module.add_function("riot_rt_init", void_type.fn_type(&[], false), None);
    let shutdown_fn = module.add_function("riot_rt_shutdown", void_type.fn_type(&[], false), None);
    let println_fn = module.add_function(
        "riot_rt_println",
        void_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        None,
    );

    let main_fn = module.add_function("main", i32_type.fn_type(&[], false), None);
    let entry = context.append_basic_block(main_fn, "entry");
    builder.position_at_end(entry);

    builder
        .build_call(init_fn, &[], "riot_rt_init")
        .map_err(|error| miette::miette!("failed to emit runtime init call: {error}"))?;

    for (index, output) in outputs.iter().enumerate() {
        let value = builder
            .build_global_string_ptr(output, &format!("out_{index}"))
            .map_err(|error| miette::miette!("failed to emit output literal: {error}"))?;
        let len = i64_type.const_int(output.len() as u64, false);
        builder
            .build_call(
                println_fn,
                &[value.as_pointer_value().into(), len.into()],
                "riot_rt_println",
            )
            .map_err(|error| miette::miette!("failed to emit output call: {error}"))?;
    }

    builder
        .build_call(shutdown_fn, &[], "riot_rt_shutdown")
        .map_err(|error| miette::miette!("failed to emit runtime shutdown call: {error}"))?;
    builder
        .build_return(Some(&i32_type.const_zero()))
        .map_err(|error| miette::miette!("failed to emit main return: {error}"))?;

    module
        .verify()
        .map_err(|error| miette::miette!("generated invalid LLVM module: {error}"))?;
    Ok(module)
}

fn evaluate_outputs(program: &RirProgram) -> miette::Result<Vec<String>> {
    let mut evaluator = Evaluator::new(program);
    let Some(main) = program.functions.iter().find(|function| function.name == "main") else {
        return Ok(Vec::new());
    };
    let mut env = HashMap::new();
    evaluator.eval_block(&main.body, &mut env)?;
    evaluator.shutdown()?;
    Ok(evaluator.outputs)
}

#[derive(Debug, Clone)]
enum Value {
    Actor(usize),
    Bool(bool),
    Char(char),
    Float(String),
    Int(i64),
    List(Vec<Value>),
    Message(String),
    Record {
        path: String,
        fields: Vec<(String, Value)>,
    },
    String(String),
    Tuple(Vec<Value>),
    Unit,
}

impl Value {
    fn to_print_string(&self) -> String {
        match self {
            Value::Actor(pid) => format!("<pid:{pid}>"),
            Value::Bool(true) => "true".to_owned(),
            Value::Bool(false) => "false".to_owned(),
            Value::Char(value) => value.to_string(),
            Value::Float(value) => value.clone(),
            Value::Int(value) => value.to_string(),
            Value::List(items) => {
                let rendered = items
                    .iter()
                    .map(Value::to_print_string)
                    .collect::<Vec<_>>()
                    .join(", ");
                format!("[{rendered}]")
            }
            Value::Message(message) | Value::String(message) => message.clone(),
            Value::Record { path, fields } => {
                let rendered = fields
                    .iter()
                    .map(|(name, value)| format!("{name}: {}", value.to_print_string()))
                    .collect::<Vec<_>>()
                    .join(", ");
                format!("{path} {{ {rendered} }}")
            }
            Value::Tuple(items) => {
                let rendered = items
                    .iter()
                    .map(Value::to_print_string)
                    .collect::<Vec<_>>()
                    .join(", ");
                format!("({rendered})")
            }
            Value::Unit => "()".to_owned(),
        }
    }

    fn as_bool(&self) -> miette::Result<bool> {
        match self {
            Value::Bool(value) => Ok(*value),
            _ => bail!("expected bool value"),
        }
    }

    fn as_int(&self) -> miette::Result<i64> {
        match self {
            Value::Int(value) => Ok(*value),
            _ => bail!("expected i64 value"),
        }
    }

    fn as_actor(&self) -> miette::Result<usize> {
        match self {
            Value::Actor(pid) => Ok(*pid),
            _ => bail!("expected actor pid"),
        }
    }
}

#[derive(Debug, Clone)]
struct Actor {
    steps: Vec<ActorStep>,
    env: HashMap<String, Value>,
    cursor: usize,
    mailbox: Vec<String>,
    monitors: usize,
    terminated: bool,
}

#[derive(Debug, Clone)]
enum ActorStep {
    Let { name: String, value: RirExpr },
    Expr(RirExpr),
}

struct Evaluator<'a> {
    functions: HashMap<&'a str, &'a RirFunction>,
    outputs: Vec<String>,
    actors: Vec<Actor>,
}

impl<'a> Evaluator<'a> {
    fn new(program: &'a RirProgram) -> Self {
        Self {
            functions: program
                .functions
                .iter()
                .map(|function| (function.name.as_str(), function))
                .collect(),
            outputs: Vec::new(),
            actors: Vec::new(),
        }
    }

    fn shutdown(&mut self) -> miette::Result<()> {
        self.schedule_until_quiescent()?;
        for pid in 1..=self.actors.len() {
            let monitors = self.actors[pid - 1].monitors;
            for _ in 0..monitors {
                self.outputs.push(format!("down {pid}"));
            }
        }
        Ok(())
    }

    fn schedule_until_quiescent(&mut self) -> miette::Result<()> {
        loop {
            let actor_count = self.actors.len();
            let mut made_progress = false;
            for index in 0..actor_count {
                if self.actors.get(index).is_none_or(|actor| actor.terminated) {
                    continue;
                }
                made_progress |= self.poll_actor(index)?;
            }
            if !made_progress {
                break;
            }
        }
        Ok(())
    }

    fn poll_actor(&mut self, index: usize) -> miette::Result<bool> {
        let mut made_progress = false;
        loop {
            let step = {
                let actor = &mut self.actors[index];
                if actor.cursor >= actor.steps.len() {
                    actor.terminated = true;
                    return Ok(true);
                }
                actor.steps[actor.cursor].clone()
            };

            match step {
                ActorStep::Let { name, value } => {
                    let mut env = self.actors[index].env.clone();
                    let value = self.eval_expr(&value, &mut env)?;
                    env.insert(name, value);
                    let actor = &mut self.actors[index];
                    actor.env = env;
                    actor.cursor += 1;
                    made_progress = true;
                }
                ActorStep::Expr(RirExpr::Receive { binder, body }) => {
                    let Some(message) = self.actors[index].mailbox.first().cloned() else {
                        return Ok(made_progress);
                    };
                    self.actors[index].mailbox.remove(0);
                    let mut env = self.actors[index].env.clone();
                    env.insert(binder, Value::Message(message));
                    self.eval_expr(&body, &mut env)?;
                    let actor = &mut self.actors[index];
                    actor.env = env;
                    actor.cursor += 1;
                    return Ok(true);
                }
                ActorStep::Expr(expr) => {
                    let mut env = self.actors[index].env.clone();
                    self.eval_expr(&expr, &mut env)?;
                    let actor = &mut self.actors[index];
                    actor.env = env;
                    actor.cursor += 1;
                    made_progress = true;
                }
            }
        }
    }

    fn eval_block(
        &mut self,
        block: &RirBlock,
        env: &mut HashMap<String, Value>,
    ) -> miette::Result<Value> {
        for stmt in &block.statements {
            match stmt {
                RirStmt::Let { name, value } => {
                    let value = self.eval_expr(value, env)?;
                    env.insert(name.clone(), value);
                }
                RirStmt::Expr(expr) => {
                    self.eval_expr(expr, env)?;
                }
            }
        }
        if let Some(tail) = &block.tail {
            self.eval_expr(tail, env)
        } else {
            Ok(Value::Unit)
        }
    }

    fn eval_expr(
        &mut self,
        expr: &RirExpr,
        env: &mut HashMap<String, Value>,
    ) -> miette::Result<Value> {
        match expr {
            RirExpr::Add(lhs, rhs) => Ok(Value::Int(
                self.eval_expr(lhs, env)?.as_int()? + self.eval_expr(rhs, env)?.as_int()?,
            )),
            RirExpr::Sub(lhs, rhs) => Ok(Value::Int(
                self.eval_expr(lhs, env)?.as_int()? - self.eval_expr(rhs, env)?.as_int()?,
            )),
            RirExpr::Mul(lhs, rhs) => Ok(Value::Int(
                self.eval_expr(lhs, env)?.as_int()? * self.eval_expr(rhs, env)?.as_int()?,
            )),
            RirExpr::Div(lhs, rhs) => {
                let lhs = self.eval_expr(lhs, env)?.as_int()?;
                let rhs = self.eval_expr(rhs, env)?.as_int()?;
                if rhs == 0 {
                    bail!("division by zero during stage0 evaluation");
                }
                Ok(Value::Int(lhs / rhs))
            }
            RirExpr::Mod(lhs, rhs) => {
                let lhs = self.eval_expr(lhs, env)?.as_int()?;
                let rhs = self.eval_expr(rhs, env)?.as_int()?;
                if rhs == 0 {
                    bail!("modulo by zero during stage0 evaluation");
                }
                Ok(Value::Int(lhs % rhs))
            }
            RirExpr::Neg(expr) => match self.eval_expr(expr, env)? {
                Value::Float(value) => Ok(Value::Float(format!("-{value}"))),
                Value::Int(value) => Ok(Value::Int(-value)),
                _ => bail!("expected numeric value for negation"),
            },
            RirExpr::Eq(lhs, rhs) => {
                let lhs = self.eval_expr(lhs, env)?;
                let rhs = self.eval_expr(rhs, env)?;
                Ok(Value::Bool(lhs.to_print_string() == rhs.to_print_string()))
            }
            RirExpr::Lt(lhs, rhs) => Ok(Value::Bool(
                self.eval_expr(lhs, env)?.as_int()? < self.eval_expr(rhs, env)?.as_int()?,
            )),
            RirExpr::And(lhs, rhs) => Ok(Value::Bool(
                self.eval_expr(lhs, env)?.as_bool()? && self.eval_expr(rhs, env)?.as_bool()?,
            )),
            RirExpr::Or(lhs, rhs) => Ok(Value::Bool(
                self.eval_expr(lhs, env)?.as_bool()? || self.eval_expr(rhs, env)?.as_bool()?,
            )),
            RirExpr::Not(expr) => Ok(Value::Bool(!self.eval_expr(expr, env)?.as_bool()?)),
            RirExpr::If {
                condition,
                then_branch,
                else_branch,
            } => {
                if self.eval_expr(condition, env)?.as_bool()? {
                    self.eval_expr(then_branch, env)
                } else {
                    self.eval_expr(else_branch, env)
                }
            }
            RirExpr::Bool(value) => Ok(Value::Bool(*value)),
            RirExpr::Call { callee, args } => self.eval_call(callee, args, env),
            RirExpr::Unit => Ok(Value::Unit),
            RirExpr::Tuple(items) => Ok(Value::Tuple(
                items
                    .iter()
                    .map(|item| self.eval_expr(item, env))
                    .collect::<miette::Result<Vec<_>>>()?,
            )),
            RirExpr::List(items) => Ok(Value::List(
                items
                    .iter()
                    .map(|item| self.eval_expr(item, env))
                    .collect::<miette::Result<Vec<_>>>()?,
            )),
            RirExpr::Record { path, fields } => Ok(Value::Record {
                path: path.join("."),
                fields: fields
                    .iter()
                    .map(|(name, value)| Ok((name.clone(), self.eval_expr(value, env)?)))
                    .collect::<miette::Result<Vec<_>>>()?,
            }),
            RirExpr::Char(value) => Ok(Value::Char(*value)),
            RirExpr::Float(value) => Ok(Value::Float(value.clone())),
            RirExpr::Int(value) => Ok(Value::Int(*value)),
            RirExpr::Path(path) => self.eval_path(path, env),
            RirExpr::String(value) => Ok(Value::String(value.clone())),
            RirExpr::Spawn { body } => Ok(Value::Actor(self.spawn_actor(body, env.clone()))),
            RirExpr::Receive { .. } => bail!("receive cannot be evaluated outside actor polling"),
        }
    }

    fn eval_path(&self, path: &[String], env: &HashMap<String, Value>) -> miette::Result<Value> {
        let Some((head, tail)) = path.split_first() else {
            bail!("empty path");
        };
        let mut value = env
            .get(head)
            .cloned()
            .ok_or_else(|| miette::miette!("unknown value `{head}`"))?;
        for segment in tail {
            let Value::Record { fields, .. } = value else {
                bail!("path segment `{segment}` is not a record field");
            };
            value = fields
                .into_iter()
                .find_map(|(name, value)| (name == *segment).then_some(value))
                .ok_or_else(|| miette::miette!("unknown record field `{segment}`"))?;
        }
        Ok(value)
    }

    fn eval_call(
        &mut self,
        callee: &[String],
        args: &[RirExpr],
        env: &mut HashMap<String, Value>,
    ) -> miette::Result<Value> {
        let [name] = callee else {
            bail!("stage0 cannot evaluate imported call `{}` yet", callee.join("."));
        };
        match name.as_str() {
            "dbg" => {
                let value = self.eval_expr(&args[0], env)?;
                self.outputs.push(value.to_print_string());
                Ok(Value::Unit)
            }
            "println" => {
                let value = self.eval_expr(&args[0], env)?;
                self.outputs.push(value.to_print_string());
                Ok(Value::Unit)
            }
            "send" => {
                let pid = self.eval_expr(&args[0], env)?.as_actor()?;
                let message = self.eval_expr(&args[1], env)?.to_print_string();
                if let Some(actor) = self.actors.get_mut(pid.saturating_sub(1)) {
                    actor.mailbox.push(message);
                }
                Ok(Value::Unit)
            }
            "monitor" => {
                let pid = self.eval_expr(&args[0], env)?.as_actor()?;
                if let Some(actor) = self.actors.get_mut(pid.saturating_sub(1)) {
                    actor.monitors = actor.monitors.saturating_add(1);
                }
                Ok(Value::Unit)
            }
            "link" => {
                let _pid = self.eval_expr(&args[0], env)?.as_actor()?;
                Ok(Value::Unit)
            }
            _ => {
                let Some(function) = self.functions.get(name.as_str()).copied() else {
                    bail!("unknown function `{name}`");
                };
                if function.params.len() != args.len() {
                    bail!("function `{name}` called with wrong arity");
                }
                let mut call_env = HashMap::new();
                for (param, arg) in function.params.iter().zip(args) {
                    let value = self.eval_expr(arg, env)?;
                    call_env.insert(param.clone(), value);
                }
                self.eval_block(&function.body, &mut call_env)
            }
        }
    }

    fn spawn_actor(&mut self, body: &RirBlock, env: HashMap<String, Value>) -> usize {
        let pid = self.actors.len() + 1;
        self.actors.push(Actor {
            steps: actor_steps(body),
            env,
            cursor: 0,
            mailbox: Vec::new(),
            monitors: 0,
            terminated: false,
        });
        pid
    }
}

fn actor_steps(block: &RirBlock) -> Vec<ActorStep> {
    let mut steps = Vec::new();
    for stmt in &block.statements {
        match stmt {
            RirStmt::Let { name, value } => steps.push(ActorStep::Let {
                name: name.clone(),
                value: value.clone(),
            }),
            RirStmt::Expr(expr) => steps.push(ActorStep::Expr(expr.clone())),
        }
    }
    if let Some(tail) = &block.tail {
        steps.push(ActorStep::Expr(tail.clone()));
    }
    steps
}
