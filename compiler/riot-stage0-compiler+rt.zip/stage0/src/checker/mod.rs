use std::collections::{HashMap, HashSet};

use camino::Utf8Path;

mod const_eval;
mod span;
mod types;

use const_eval::{ConstFunction, ConstValue, resolve_const_value};
use span::expr_span;
use types::parse_primitive_type;

use crate::ast::{AstBlock, AstDecl, AstExpr, AstProgram, AstStmt, AstTypeAnnotation, TextSpan};
use crate::diagnostic::to_source_diagnostic;
use crate::ir::{CheckedProgram, signature_for, typed_program_from_ast};
use crate::signature::{ImportedSignatures, RsigType, parse_type};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum CheckMode {
    Executable,
    Interface,
}

pub(crate) fn typecheck(
    source_path: &Utf8Path,
    source: &str,
    module_name: String,
    program: AstProgram,
    imports: &ImportedSignatures,
    mode: CheckMode,
) -> miette::Result<CheckedProgram> {
    validate_program(source_path, source, &program, imports, mode)?;
    let typed_tree = typed_program_from_ast(module_name, program);
    let signature = signature_for(&typed_tree);
    Ok(CheckedProgram {
        typed_tree,
        signature,
    })
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum BindingKind {
    Actor,
    Value,
    Message,
}

#[derive(Debug)]
struct ValidationContext<'a> {
    source_path: &'a Utf8Path,
    source: &'a str,
    functions: HashMap<String, ConstFunction>,
    function_names: HashSet<String>,
    external_names: HashSet<String>,
    imports: &'a ImportedSignatures,
}

fn validate_program(
    source_path: &Utf8Path,
    source: &str,
    program: &AstProgram,
    imports: &ImportedSignatures,
    mode: CheckMode,
) -> miette::Result<()> {
    let functions = const_functions(program);
    let function_names = functions.keys().cloned().collect::<HashSet<_>>();
    let external_names = external_names(program);
    let ctx = ValidationContext {
        source_path,
        source,
        functions,
        function_names,
        external_names,
        imports,
    };

    let main_decls = program
        .decls
        .iter()
        .filter_map(|decl| match decl {
            AstDecl::Function(function) if function.name == "main" => Some(function),
            _ => None,
        })
        .collect::<Vec<_>>();

    if main_decls.len() > 1 {
        let duplicate = main_decls[1];
        return Err(to_source_diagnostic(
            source_path,
            source,
            duplicate.span,
            "duplicate main function",
            "stage0 requires a single main function per file",
            Some("keep only one `fn main() { ... }`"),
        )
        .into());
    }

    if mode == CheckMode::Executable && main_decls.is_empty() {
        let span = first_decl_span(program).unwrap_or_else(|| TextSpan::new(0, source.len().min(1)));
        return Err(to_source_diagnostic(
            source_path,
            source,
            span,
            "missing main function",
            "stage0 compile requires one entrypoint named main",
            Some("add: fn main() { dbg(\"hello world\") }"),
        )
        .into());
    }

    for decl in &program.decls {
        match decl {
            AstDecl::Use(use_) => {
                if !imports.contains_key(&use_.name) {
                    return Err(to_source_diagnostic(
                        source_path,
                        source,
                        use_.name_span,
                        "missing imported signature",
                        format!("`use {}` did not resolve to a signature", use_.name),
                        Some("pass --sig-dir with the directory containing the .rsig file"),
                    )
                    .into());
                }
            }
            AstDecl::External(external) => {
                if external.type_text.trim().is_empty() {
                    return Err(to_source_diagnostic(
                        source_path,
                        source,
                        external.type_span,
                        "empty external type",
                        "external declarations need a source-level type",
                        Some("try: external println : string -> unit = \"riot_prim_println\""),
                    )
                    .into());
                }
            }
            AstDecl::Function(function) => {
                if function.name == "main" && !function.params.is_empty() {
                    return Err(to_source_diagnostic(
                        source_path,
                        source,
                        function.name_span,
                        "main function cannot have parameters",
                        "stage0 requires main to have no parameters",
                        Some("try: fn main() { dbg(\"hello world\") }"),
                    )
                    .into());
                }
                validate_block(&ctx, &function.body, function.name == "main")?;
            }
        }
    }

    Ok(())
}

fn const_functions(program: &AstProgram) -> HashMap<String, ConstFunction> {
    program
        .decls
        .iter()
        .filter_map(|decl| match decl {
            AstDecl::Function(function) if function.name != "main" => Some((
                function.name.clone(),
                ConstFunction {
                    params: function.params.clone(),
                    body: function.body.clone(),
                },
            )),
            _ => None,
        })
        .collect()
}

fn external_names(program: &AstProgram) -> HashSet<String> {
    let mut names = HashSet::from([
        "dbg".to_owned(),
        "println".to_owned(),
        "send".to_owned(),
        "monitor".to_owned(),
        "link".to_owned(),
    ]);
    for decl in &program.decls {
        if let AstDecl::External(external) = decl {
            names.insert(external.name.clone());
        }
    }
    names
}

fn first_decl_span(program: &AstProgram) -> Option<TextSpan> {
    program.decls.first().map(|decl| match decl {
        AstDecl::Use(use_) => use_.span,
        AstDecl::External(external) => external.span,
        AstDecl::Function(function) => function.span,
    })
}

fn validate_block(
    ctx: &ValidationContext<'_>,
    block: &AstBlock,
    is_main: bool,
) -> miette::Result<()> {
    let mut bindings = HashMap::<String, BindingKind>::new();
    let mut output_actions = 0_usize;
    let mut actor_actions = 0_usize;

    for stmt in &block.statements {
        match stmt {
            AstStmt::Let {
                name,
                name_span,
                type_annotation,
                value,
                span: _,
            } => {
                if bindings.contains_key(name) {
                    return Err(to_source_diagnostic(
                        ctx.source_path,
                        ctx.source,
                        *name_span,
                        "duplicate local binding",
                        format!("`{name}` is already bound in this block"),
                        Some("use a unique local name"),
                    )
                    .into());
                }
                if let Some(annotation) = type_annotation {
                    validate_type_annotation(ctx, annotation, value, &bindings)?;
                }
                let kind = match value {
                    AstExpr::Spawn { body, span: _ } => {
                        validate_actor_block(ctx, body)?;
                        actor_actions += 1;
                        BindingKind::Actor
                    }
                    _ => {
                        validate_expr(ctx, value, &bindings, false)?;
                        BindingKind::Value
                    }
                };
                bindings.insert(name.clone(), kind);
            }
            AstStmt::Expr(expr) => {
                let category = validate_expr(ctx, expr, &bindings, false)?;
                match category {
                    ExprCategory::Output => output_actions += 1,
                    ExprCategory::Actor => actor_actions += 1,
                    ExprCategory::Other => {}
                }
            }
        }
    }

    if let Some(tail) = &block.tail {
        let category = validate_expr(ctx, tail, &bindings, false)?;
        match category {
            ExprCategory::Output => output_actions += 1,
            ExprCategory::Actor => actor_actions += 1,
            ExprCategory::Other => {}
        }
    }

    if is_main && output_actions == 0 && actor_actions == 0 {
        return Err(to_source_diagnostic(
            ctx.source_path,
            ctx.source,
            block.span,
            "unsupported main body",
            "stage0 expects main to produce output or actor actions",
            Some("try: fn main() { dbg(\"hello world\") }"),
        )
        .into());
    }

    if is_main && actor_actions == 0 && output_actions > 1 {
        return Err(to_source_diagnostic(
            ctx.source_path,
            ctx.source,
            block.span,
            "unsupported main body",
            "stage0 currently allows one direct output expression unless actor actions are present",
            Some("use a single dbg/println expression"),
        )
        .into());
    }

    Ok(())
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ExprCategory {
    Output,
    Actor,
    Other,
}

fn validate_expr(
    ctx: &ValidationContext<'_>,
    expr: &AstExpr,
    bindings: &HashMap<String, BindingKind>,
    in_actor: bool,
) -> miette::Result<ExprCategory> {
    match expr {
        AstExpr::Call { callee, args, span } => {
            if let [module, name] = callee.segments.as_slice() {
                let Some(rsig) = ctx.imports.get(module) else {
                    return Err(to_source_diagnostic(
                        ctx.source_path,
                        ctx.source,
                        *span,
                        "unknown imported module",
                        format!("`{module}` has not been brought into scope with `use {module}`"),
                        Some("add a top-level `use` declaration and pass --sig-dir"),
                    )
                    .into());
                };
                if rsig.find(name).is_none() {
                    return Err(to_source_diagnostic(
                        ctx.source_path,
                        ctx.source,
                        *span,
                        "unknown imported value",
                        format!("module `{module}` does not export `{name}`"),
                        Some("check the producer .rsig"),
                    )
                    .into());
                }
                for arg in args {
                    validate_expr(ctx, arg, bindings, in_actor)?;
                }
                return Ok(ExprCategory::Other);
            }

            let [name] = callee.segments.as_slice() else {
                return Err(to_source_diagnostic(
                    ctx.source_path,
                    ctx.source,
                    *span,
                    "unsupported path call",
                    "stage0 only supports local calls and qualified module calls",
                    Some("try: Module.value(...)"),
                )
                .into());
            };

            match name.as_str() {
                "dbg" => {
                    if args.len() != 1 {
                        return Err(call_arity_error(ctx, *span, "dbg", 1, args.len()).into());
                    }
                    validate_expr(ctx, &args[0], bindings, in_actor)?;
                    Ok(ExprCategory::Output)
                }
                "println" => {
                    if args.len() != 1 {
                        return Err(call_arity_error(ctx, *span, "println", 1, args.len()).into());
                    }
                    validate_expr(ctx, &args[0], bindings, in_actor)?;
                    Ok(ExprCategory::Output)
                }
                "send" => {
                    if args.len() != 2 {
                        return Err(call_arity_error(ctx, *span, "send", 2, args.len()).into());
                    }
                    validate_actor_target(ctx, &args[0], bindings, *span, "send")?;
                    validate_expr(ctx, &args[1], bindings, in_actor)?;
                    Ok(ExprCategory::Actor)
                }
                "monitor" | "link" => {
                    if args.len() != 1 {
                        return Err(call_arity_error(ctx, *span, name, 1, args.len()).into());
                    }
                    validate_actor_target(ctx, &args[0], bindings, *span, name)?;
                    Ok(ExprCategory::Actor)
                }
                _ if ctx.function_names.contains(name) || ctx.external_names.contains(name) => {
                    for arg in args {
                        validate_expr(ctx, arg, bindings, in_actor)?;
                    }
                    Ok(ExprCategory::Other)
                }
                _ => Err(to_source_diagnostic(
                    ctx.source_path,
                    ctx.source,
                    *span,
                    "unsupported function call",
                    format!("stage0 does not know `{name}`"),
                    Some("try: dbg(\"hello world\")"),
                )
                .into()),
            }
        }
        AstExpr::Spawn { body, span: _ } => {
            validate_actor_block(ctx, body)?;
            Ok(ExprCategory::Actor)
        }
        AstExpr::Receive { span, .. } if !in_actor => Err(to_source_diagnostic(
            ctx.source_path,
            ctx.source,
            *span,
            "receive outside spawn",
            "`receive` is only valid inside an actor body",
            Some("wrap the receive in `spawn { ... }`"),
        )
        .into()),
        AstExpr::Receive { body, .. } => {
            validate_expr(ctx, body, bindings, true)?;
            Ok(ExprCategory::Actor)
        }
        AstExpr::Add { lhs, rhs, .. }
        | AstExpr::Sub { lhs, rhs, .. }
        | AstExpr::Mul { lhs, rhs, .. }
        | AstExpr::Div { lhs, rhs, .. }
        | AstExpr::Mod { lhs, rhs, .. }
        | AstExpr::Eq { lhs, rhs, .. }
        | AstExpr::Lt { lhs, rhs, .. }
        | AstExpr::And { lhs, rhs, .. }
        | AstExpr::Or { lhs, rhs, .. } => {
            validate_expr(ctx, lhs, bindings, in_actor)?;
            validate_expr(ctx, rhs, bindings, in_actor)?;
            Ok(ExprCategory::Other)
        }
        AstExpr::Neg { expr, .. } | AstExpr::Not { expr, .. } => {
            validate_expr(ctx, expr, bindings, in_actor)?;
            Ok(ExprCategory::Other)
        }
        AstExpr::If {
            condition,
            then_branch,
            else_branch,
            ..
        } => {
            validate_expr(ctx, condition, bindings, in_actor)?;
            validate_expr(ctx, then_branch, bindings, in_actor)?;
            validate_expr(ctx, else_branch, bindings, in_actor)?;
            Ok(ExprCategory::Other)
        }
        AstExpr::Tuple { items, .. } | AstExpr::List { items, .. } => {
            for item in items {
                validate_expr(ctx, item, bindings, in_actor)?;
            }
            Ok(ExprCategory::Other)
        }
        AstExpr::Record { fields, .. } => {
            for (_, value) in fields {
                validate_expr(ctx, value, bindings, in_actor)?;
            }
            Ok(ExprCategory::Other)
        }
        AstExpr::Bool { .. }
        | AstExpr::Char { .. }
        | AstExpr::Unit { .. }
        | AstExpr::Float { .. }
        | AstExpr::Int { .. }
        | AstExpr::Path { .. }
        | AstExpr::String { .. } => Ok(ExprCategory::Other),
    }
}

fn validate_actor_block(ctx: &ValidationContext<'_>, block: &AstBlock) -> miette::Result<()> {
    let mut bindings = HashMap::<String, BindingKind>::new();
    let mut has_receive = false;

    for stmt in &block.statements {
        match stmt {
            AstStmt::Let {
                name,
                value,
                type_annotation,
                ..
            } => {
                if type_annotation.is_some() {
                    return Err(to_source_diagnostic(
                        ctx.source_path,
                        ctx.source,
                        expr_span(value),
                        "unsupported actor local annotation",
                        "stage0 actor locals do not support type annotations yet",
                        Some("omit the annotation"),
                    )
                    .into());
                }
                if let AstExpr::Spawn { body, .. } = value {
                    validate_actor_block(ctx, body)?;
                    bindings.insert(name.clone(), BindingKind::Actor);
                } else {
                    validate_expr(ctx, value, &bindings, true)?;
                    bindings.insert(name.clone(), BindingKind::Value);
                }
            }
            AstStmt::Expr(expr) => {
                if let AstExpr::Receive { binder, body, .. } = expr {
                    has_receive = true;
                    let mut receive_bindings = bindings.clone();
                    receive_bindings.insert(binder.clone(), BindingKind::Message);
                    validate_expr(ctx, body, &receive_bindings, true)?;
                } else {
                    validate_expr(ctx, expr, &bindings, true)?;
                }
            }
        }
    }

    if let Some(tail) = &block.tail {
        if let AstExpr::Receive { binder, body, .. } = tail {
            has_receive = true;
            let mut receive_bindings = bindings.clone();
            receive_bindings.insert(binder.clone(), BindingKind::Message);
            validate_expr(ctx, body, &receive_bindings, true)?;
        } else {
            validate_expr(ctx, tail, &bindings, true)?;
        }
    }

    if !has_receive {
        return Err(to_source_diagnostic(
            ctx.source_path,
            ctx.source,
            block.span,
            "actor body never receives",
            "stage0 actors must contain at least one receive point",
            Some("try: spawn { receive { msg -> dbg(msg) } }"),
        )
        .into());
    }

    Ok(())
}

fn validate_actor_target(
    ctx: &ValidationContext<'_>,
    expr: &AstExpr,
    bindings: &HashMap<String, BindingKind>,
    span: TextSpan,
    operation: &str,
) -> miette::Result<()> {
    if let AstExpr::Path { path, .. } = expr
        && let [name] = path.segments.as_slice()
    {
        match bindings.get(name) {
            Some(BindingKind::Actor) | Some(BindingKind::Message) | None => return Ok(()),
            Some(BindingKind::Value) => {
                return Err(to_source_diagnostic(
                    ctx.source_path,
                    ctx.source,
                    span,
                    format!("{operation} target is not an actor"),
                    format!("`{name}` is a value, not a pid"),
                    Some("send to the result of `spawn { ... }`"),
                )
                .into());
            }
        }
    }
    validate_expr(ctx, expr, bindings, false)?;
    Ok(())
}

fn validate_type_annotation(
    ctx: &ValidationContext<'_>,
    annotation: &AstTypeAnnotation,
    value: &AstExpr,
    _bindings: &HashMap<String, BindingKind>,
) -> miette::Result<()> {
    if annotation.text == "int" || annotation.text == "float" {
        let error = parse_primitive_type(&annotation.text).unwrap_err();
        return Err(to_source_diagnostic(
            ctx.source_path,
            ctx.source,
            annotation.span,
            "unsupported type annotation",
            error.message,
            error.help,
        )
        .into());
    }

    if parse_primitive_type(&annotation.text).is_err()
        && !annotation.text.starts_with('(')
        && !annotation.text.ends_with(" list")
    {
        return Ok(());
    }

    let value_type = resolve_const_value(value, &HashMap::new(), &ctx.functions)
        .map(|value| const_value_type(&value));
    if let Some(value_type) = value_type {
        let expected = parse_type(&annotation.text);
        if type_matches(&expected, &value_type) {
            return Ok(());
        }
        return Err(to_source_diagnostic(
            ctx.source_path,
            ctx.source,
            annotation.span,
            "type annotation does not match value",
            format!(
                "expected `{}`, but this binding has type `{}`",
                expected.canonical(),
                value_type.canonical()
            ),
            Some("change the annotation or the value"),
        )
        .into());
    }

    Ok(())
}

fn const_value_type(value: &ConstValue) -> RsigType {
    match value {
        ConstValue::Bool(_) => RsigType::Bool,
        ConstValue::Char(_) => RsigType::Char,
        ConstValue::Float(_) => RsigType::F64,
        ConstValue::Int(_) => RsigType::I64,
        ConstValue::String(_) => RsigType::String,
        ConstValue::Unit => RsigType::Unit,
        ConstValue::Tuple(items) => RsigType::Tuple(items.iter().map(const_value_type).collect()),
        ConstValue::List(items) => RsigType::List(Box::new(
            items.first().map(const_value_type).unwrap_or(RsigType::Unknown),
        )),
        ConstValue::Record { path, fields: _ } => RsigType::Record(path.clone()),
    }
}

fn type_matches(expected: &RsigType, actual: &RsigType) -> bool {
    expected == actual || matches!(expected, RsigType::Unknown) || matches!(actual, RsigType::Unknown)
}

fn call_arity_error(
    ctx: &ValidationContext<'_>,
    span: TextSpan,
    name: &str,
    expected: usize,
    actual: usize,
) -> miette::Report {
    to_source_diagnostic(
        ctx.source_path,
        ctx.source,
        span,
        format!("{name} expects {expected} argument(s)"),
        format!("found {actual} argument(s)"),
        Some("check the call arity"),
    )
    .into()
}
