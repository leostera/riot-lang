let main () = println "hello world"
