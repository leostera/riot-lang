#![deny(unsafe_op_in_unsafe_fn)]

use std::alloc::{Layout, alloc_zeroed};
use std::cell::Cell;
use std::io::{self, Write};
use std::ptr;
use std::slice;
use std::sync::{Mutex, OnceLock};

const POLL_CONSUMED: u32 = 1;
const POLL_DONE: u32 = 2;
const POLL_PROGRESS: u32 = 4;

static RUNTIME: OnceLock<Mutex<Runtime>> = OnceLock::new();

thread_local! {
    static ACTIVE_RUNTIME: Cell<*mut Runtime> = const { Cell::new(ptr::null_mut()) };
}

type ActorResumeFn = unsafe extern "C" fn(*mut u8, u64, *const RtMessage) -> u32;

#[repr(C)]
pub struct RtMessage {
    ptr: *const u8,
    len: usize,
}

#[derive(Default)]
struct Runtime {
    actors: Vec<ActorSlot>,
}

struct ActorSlot {
    frame: usize,
    resume: ActorResumeFn,
    mailbox: Vec<Vec<u8>>,
    monitors: usize,
    linked: bool,
    terminated: bool,
}

impl Runtime {
    fn spawn(&mut self, frame: *mut u8, resume: ActorResumeFn) -> u64 {
        if frame.is_null() {
            return 0;
        }

        self.actors.push(ActorSlot {
            frame: frame as usize,
            resume,
            mailbox: Vec::new(),
            monitors: 0,
            linked: false,
            terminated: false,
        });
        self.actors.len() as u64
    }

    fn send(&mut self, pid: u64, message: Vec<u8>) {
        let Some(index) = pid_index(pid) else {
            return;
        };
        let Some(actor) = self.actors.get_mut(index) else {
            return;
        };
        if !actor.terminated {
            actor.mailbox.push(message);
        }
    }

    fn monitor(&mut self, pid: u64) {
        let Some(index) = pid_index(pid) else {
            return;
        };
        if let Some(actor) = self.actors.get_mut(index) {
            actor.monitors = actor.monitors.saturating_add(1);
        }
    }

    fn link(&mut self, pid: u64) {
        let Some(index) = pid_index(pid) else {
            return;
        };
        if let Some(actor) = self.actors.get_mut(index) {
            actor.linked = true;
        }
    }

    fn shutdown(&mut self) {
        self.schedule_until_quiescent();

        for actor in &mut self.actors {
            actor.terminated = true;
        }

        for (index, actor) in self.actors.iter().enumerate() {
            let _linked = actor.linked;
            let pid = index + 1;
            for _ in 0..actor.monitors {
                write_bytes_line(format!("down {pid}").as_bytes());
            }
        }

        self.actors.clear();
    }

    fn schedule_until_quiescent(&mut self) {
        loop {
            let mut made_progress = false;
            let actor_count = self.actors.len();

            for index in 0..actor_count {
                if self.actors.get(index).is_none_or(|actor| actor.terminated) {
                    continue;
                }

                let pid = (index + 1) as u64;
                let (frame, resume, current_message) = {
                    let actor = &self.actors[index];
                    (
                        actor.frame as *mut u8,
                        actor.resume,
                        actor.mailbox.first().cloned(),
                    )
                };
                let message = current_message.as_ref().map(|bytes| RtMessage {
                    ptr: bytes.as_ptr(),
                    len: bytes.len(),
                });
                let message_ptr = message
                    .as_ref()
                    .map_or(ptr::null(), |message| message as *const RtMessage);

                let previous = ACTIVE_RUNTIME.with(|active| {
                    let previous = active.replace(self as *mut Runtime);
                    let result = unsafe { resume(frame, pid, message_ptr) };
                    active.set(previous);
                    (previous, result)
                });
                let (_previous_runtime, result) = previous;

                made_progress |= result & POLL_PROGRESS != 0;

                if let Some(actor) = self.actors.get_mut(index) {
                    if result & POLL_CONSUMED != 0 && !actor.mailbox.is_empty() {
                        actor.mailbox.remove(0);
                    }
                    if result & POLL_DONE != 0 {
                        actor.terminated = true;
                        made_progress = true;
                    }
                }
            }

            if !made_progress {
                break;
            }
        }
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn riot_rt_init() {
    with_runtime_mut(|runtime| runtime.shutdown());
}

#[unsafe(no_mangle)]
pub extern "C" fn riot_rt_shutdown() {
    with_runtime_mut(|runtime| runtime.shutdown());
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn riot_rt_println(ptr: *const u8, len: usize) {
    unsafe { write_stdout_line(ptr, len) };
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn riot_prim_println(ptr: *const u8, len: usize) {
    unsafe { riot_rt_println(ptr, len) };
}

#[unsafe(no_mangle)]
pub extern "C" fn riot_rt_println_i64(value: i64) {
    write_bytes_line(value.to_string().as_bytes());
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn riot_rt_dbg(ptr: *const u8, len: usize) {
    unsafe { write_stdout_line(ptr, len) };
}

#[unsafe(no_mangle)]
pub extern "C" fn riot_rt_dbg_i64(value: i64) {
    write_bytes_line(value.to_string().as_bytes());
}

#[unsafe(no_mangle)]
pub extern "C" fn riot_rt_alloc_frame(size: usize) -> *mut u8 {
    let Ok(layout) = Layout::from_size_align(size.max(1), 8) else {
        return ptr::null_mut();
    };
    unsafe { alloc_zeroed(layout) }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn riot_rt_spawn_actor(frame: *mut u8, resume: Option<ActorResumeFn>) -> u64 {
    let Some(resume) = resume else {
        return 0;
    };
    with_runtime_mut(|runtime| runtime.spawn(frame, resume)).unwrap_or(0)
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn riot_rt_send(pid: u64, ptr: *const u8, len: usize) {
    let Some(bytes) = (unsafe { bytes_from_raw(ptr, len) }) else {
        return;
    };

    with_runtime_mut(|runtime| runtime.send(pid, bytes.to_vec()));
}

#[unsafe(no_mangle)]
pub extern "C" fn riot_rt_send_i64(pid: u64, value: i64) {
    with_runtime_mut(|runtime| runtime.send(pid, value.to_string().into_bytes()));
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn riot_rt_send_msg(pid: u64, message: *const RtMessage) {
    let Some(bytes) = (unsafe { message_bytes(message) }) else {
        return;
    };

    with_runtime_mut(|runtime| runtime.send(pid, bytes.to_vec()));
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn riot_rt_dbg_msg(message: *const RtMessage) {
    let Some(bytes) = (unsafe { message_bytes(message) }) else {
        return;
    };

    write_bytes_line(bytes);
}

#[unsafe(no_mangle)]
pub extern "C" fn riot_rt_monitor(pid: u64) {
    with_runtime_mut(|runtime| runtime.monitor(pid));
}

#[unsafe(no_mangle)]
pub extern "C" fn riot_rt_link(pid: u64) {
    with_runtime_mut(|runtime| runtime.link(pid));
}

fn with_runtime_mut<R>(f: impl FnOnce(&mut Runtime) -> R) -> Option<R> {
    let active_runtime = ACTIVE_RUNTIME.with(Cell::get);
    if !active_runtime.is_null() {
        return Some(unsafe { f(&mut *active_runtime) });
    }

    runtime().lock().ok().map(|mut runtime| f(&mut runtime))
}

fn runtime() -> &'static Mutex<Runtime> {
    RUNTIME.get_or_init(|| Mutex::new(Runtime::default()))
}

fn pid_index(pid: u64) -> Option<usize> {
    usize::try_from(pid).ok()?.checked_sub(1)
}

unsafe fn write_stdout_line(ptr: *const u8, len: usize) {
    let Some(bytes) = (unsafe { bytes_from_raw(ptr, len) }) else {
        return;
    };
    write_bytes_line(bytes);
}

unsafe fn message_bytes<'a>(message: *const RtMessage) -> Option<&'a [u8]> {
    let message = unsafe { message.as_ref() }?;
    unsafe { bytes_from_raw(message.ptr, message.len) }
}

unsafe fn bytes_from_raw<'a>(ptr: *const u8, len: usize) -> Option<&'a [u8]> {
    if len == 0 {
        return Some(&[]);
    }

    if ptr.is_null() && len != 0 {
        return None;
    }

    Some(unsafe { slice::from_raw_parts(ptr, len) })
}

fn write_bytes_line(bytes: &[u8]) {
    let mut stdout = io::stdout().lock();
    let _ = stdout.write_all(bytes);
    let _ = stdout.write_all(b"\n");
}
